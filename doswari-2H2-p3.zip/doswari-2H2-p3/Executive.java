public class Executive extends Salaried
{
// payRate represents annual salary
   
   public Executive(int ID, String firstName, String lastName, double payRate)
   {
      super(ID,firstName,lastName,payRate);
   }
   public double getPaid()
   {
      double total =  getBonus() + this.getPayRate()/12;//monthly bonus + monthly pay
      return total;
   }
   public double getBonus()
   {
      return this.getPayRate()/12*.01; //bonus per month
   }
   public String employeeType()
   {
      return "Executive";
   }


}