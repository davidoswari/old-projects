#preprocessing
import pandas as pd
from scipy.sparse import csr_matrix
from sklearn.neighbors import NearestNeighbors
import csv  

#create csv file for data
with open('train.dat') as dat_file, open('file.csv', 'w') as csv_file:
    csv_writer = csv.writer(csv_file)
    for line in dat_file:
        row = [field.strip() for field in line.split(' ')]
        if len(row) == 3:
            csv_writer.writerow(row)
#read data
ratings = pd.read_csv('file.csv')

#want to create mxn array 
#m is number of movies
#n is number of users

df_movie_features = ratings.pivot(
    index='movieID',
    columns='userID',
    values='rating'
).fillna(0)

matrix = csr_matrix(df_movie_features.values)
print(df_movie_features)

#get test data
testfile = open('test.dat','r')
file = testfile.readlines()
for i in range (1,len(file)):
    temp = file[i].split(' ')
    movie = temp[1]
    
    









