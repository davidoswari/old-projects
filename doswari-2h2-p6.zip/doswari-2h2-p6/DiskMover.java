/**
  *@author: David Oswari
  *@version: 1.0
  *Computes the moves to solve the Tower of Hanoi puzzle.
  */
public class DiskMover
{
   private int sourcePeg, targetPeg, auxPeg, numberOfDisks;
   private DiskMover dm;
   private int state;
  
   //states
   private final int BEFORE_LARGEST = 1;
   private final int LARGEST = 2;
   private final int AFTER_LARGEST = 3;
   private final int DONE = 4;
   
   /**
     *Constructs a disk mover.
     *@param sourcePeg the source peg
     *@param targetPeg the target peg
     *@param numberOfDisks the number of disks
   */
   public DiskMover(int numberOfDisks, int sourcePeg, int targetPeg)
   {
      this.sourcePeg = sourcePeg;
      this.targetPeg = targetPeg;
      this.numberOfDisks = numberOfDisks;
      int auxPeg = 6 - sourcePeg - targetPeg;
      state = BEFORE_LARGEST;
             
     //makes new DiskMovers if there is more than one disk, that will go to auxilary peg; 
      if (numberOfDisks > 1)
         dm = new DiskMover(numberOfDisks-1, sourcePeg, auxPeg);
   }

   /**
     *Checks if there are more moves.
     *@return true if there are more moves, false if the puzzle 
     *was solved.
     */
   public boolean hasMoreMoves()
   {
   //if state is not DONE, return true
      if(state == DONE)
         return false;
      
      else
         return true;
   }

   /**
     *Returns the next move
     *@return a description of the next move
     */
   public String nextMove()
   {
   //move largest disk
      if (numberOfDisks == 1)
      {
         state = DONE;
         return "Move disk from " + sourcePeg + " to peg " + targetPeg;
      }
   
   // if state is largest and there is more than one disk
      if (state == LARGEST)
      {
         state = AFTER_LARGEST;
         int auxPeg = 6 - sourcePeg - targetPeg;
         
         //makes a new DiskMover to move smaller disks from auxilary to target
         dm = new DiskMover(numberOfDisks-1,auxPeg, targetPeg);
         return "Move disk from " + sourcePeg + " to peg " + targetPeg;
      }
      
      String temp = dm.nextMove();
   
      if (dm.hasMoreMoves() == false)
      {
      //if state is BEFORE_LARGEST, change state to LARGEST                  
         if (state == BEFORE_LARGEST)
            state = LARGEST;
         else
            state = DONE;
      }
      
      return temp;
   }
}
