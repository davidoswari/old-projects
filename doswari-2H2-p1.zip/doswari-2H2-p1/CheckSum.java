public class CheckSum{
   public static int [] computeCheckSum(int [] data)
   {
      int sum1=0;
      int sum2=0;
   
      for(int i=0;i<data.length;i++)
      {
         sum1= sum1 + data[i];
         sum2= sum2 + sum1;
      }
      int[] result = new int[]{sum1,sum2};// array with size of 2
      
      return result;
   
   }
   public static int [] computeCheckSum(String message)//turns string to int[]
   {
      int[] array = RunCheckSum.stringToInts(message); //uses method from RunCheckSum
   
      return computeCheckSum(array); // uses other computeCheckSum method
   
   }
   public static boolean verifyCheckSum(int [] data, int [] expected)
   {
      int[] array = computeCheckSum(data);
      for(int i=0;i<expected.length;i++)
      {
         if(array[i]!=expected[i])//checks if not equal
            return false;
      }
      return true;
   }

   public static boolean verifyCheckSum(String message, String expectedHex)
   {
      int [] sum1 = RunCheckSum.stringToInts(message); 
      int [] sum2 = RunCheckSum.hexStringToInts(expectedHex);
     
      return verifyCheckSum(sum1,sum2);
   
   }
}