import java.util.Arrays;
//David Oswari G01013002
//DirectFile class
public class DirectFile
{
   public DirectFile(Disk disk, int recordSize, int keySize,
                     int firstAllocated, int bucketsAllocated)
   {
      this.disk = disk;
      this.recordSize = recordSize;
      this.keySize = keySize;
      this.firstAllocated = firstAllocated;
      this.bucketsAllocated = bucketsAllocated;
      this.recordsPerSector = disk.getSectorSize()/recordSize;
      this.firstOverflow = firstAllocated + bucketsAllocated;
      this.overflowBuckets =1;
      this.buffer = new char[disk.getSectorSize()];   
   }
   //helper method to print record at index
   public void printRecord(int index)
   {
      String mount="";
      String country="";
      String alt="";
      //mountain name
      for(int i=index;i<index+27;i++)
      {
         if(buffer[i]=='\000')
            break;
         mount += buffer[i];
      }
      //country
      for(int k=index+27;k<index+54;k++)
      {
         if(buffer[k]=='\000')
            break;
         country += buffer[k];
      }
      //altitude
      for(int j=index+54;j<index+60;j++)
      {
         if(buffer[j]=='\000')
            break;
         alt += buffer[j];
      }
      //print message
      System.out.println(mount + ", " + country + ", altitude: "+alt+" ft.\n");
   }
   //helper method that returns the key of a given record
   public char[] getKey(char[] record)
   {
      char[] key = new char[keySize];
      for(int i=0;i<keySize;i++)
         key[i]=record[i];
      return key;
   }
   //helper method that returns the index of a key
   public int indexOfKey(char[] key)
   {
      
      for(int i=0;i<buffer.length;i+=recordSize)
      {
         int match=0;
         int pos=0;
         if(buffer[i]==key[pos])//first character matches
         {
            for(int k=i;k<i+keySize;k++)
            {
               if(buffer[k]==key[pos++])
                  match++;
            }
            //if number of matching characters == keySize, found it!
            if(match==keySize)
            {
               return i;
            }
         }
      }
      return -1;
   
   }
   //helper method that returns the index of null
   public int indexOfNull()
   {
      for(int i=0;i<buffer.length;i+=recordSize)
      {
      //check if there is room in sector to insert record
         if(buffer[i]=='\000' && i+recordSize<buffer.length)
            return i;
      }
      
      return -1;
   }
   //NOTE: if indexOfNULL and indexOfKey both return -1, then sector is full
   
   //helper method that copies record into buffer
   public void copyRecord(char[] record, int index)
   {
      int pos=0;
      //copy character by character
      for(int i=index; i<index+recordSize; i++)
      {
         buffer[i] = record[pos];
         pos++;
      }
   }
   
   public boolean insertRecord(char[] record)
   {
      char[] key = getKey(record);
      int sector = hash(key);
   //first look in sector
      disk.readSector(sector,buffer);
      
      if(indexOfKey(key)>=0)
      {
         System.out.println("duplicate key\n");
         return false;
      }
      else if(indexOfKey(key)==-1 && indexOfNull()>=0)
      {
         copyRecord(record,indexOfNull());
         disk.writeSector(sector,buffer);
         return true;
      }
      //look in overflow, same process    
      else
      {
         for(int i=0;i<overflowBuckets;i++)//loop all overflow buckets
         {
            sector = firstOverflow+i;
            disk.readSector(sector,buffer);
            
            if(indexOfKey(key)>=0)
            {
               System.out.println("duplicate key\n");
               return false;
            }
            else if(indexOfKey(key)==-1 && indexOfNull()>=0)
            {
               copyRecord(record,indexOfNull());
               disk.writeSector(sector,buffer);
               return true;
            }
         }
         //if reaches here, all overflow is full, so create new overflow
         sector = firstOverflow+ overflowBuckets;
         
         //if disk is "full" and you cannot create more overflow
         if(sector >= disk.getSectorCount())
         {
            System.out.println("cannot create more overflow buckets");
            return false;
         }
         disk.readSector(sector,buffer);
         copyRecord(record,indexOfNull());
         disk.writeSector(sector,buffer);
         overflowBuckets++;
         return true;
      }
   }   
   public boolean findRecord(char[] record)
   {
      char[] key = getKey(record);
      int sector = hash(key);
   //first look in sector
      disk.readSector(sector,buffer);
      if(indexOfKey(key)>=0)
      {
      //found it!
         printRecord(indexOfKey(key));
         return true;
      }
      else if(indexOfNull()>=0 &&indexOfKey(key)==-1)
         return false;
         
      //look in overflow
      else
      {
         for(int i=0;i<overflowBuckets;i++)//loop all overflow buckets
         {
            sector = firstOverflow+i;
            disk.readSector(sector,buffer);
            if(indexOfKey(key)>=0)
            {
            //found it
               printRecord(indexOfKey(key));
               return true;
            }
            else if(indexOfNull()>=0 &&indexOfKey(key)==-1)
            {
               return false;
            }
         }
      }
   //if reached here then overflow was full, and record was not found
      return false;
   
   }   
   private int hash(char[] key)
   {
      String temp = new String(key);
      return firstAllocated + Math.abs(temp.hashCode()) % bucketsAllocated;
   }
               
   private Disk disk;             // disk on which the file will be written
   private char[] buffer;         // disk buffer
   private int recordSize;        // in characters
   private int keySize;           // in chaduracters
   private int recordsPerSector;
   private int firstAllocated;    // sector number
   private int bucketsAllocated;  // buckets (i.e. sectors) originally allocated   
   private int firstOverflow;     // sector number
   private int overflowBuckets;   // count of overflow buckets in use
}