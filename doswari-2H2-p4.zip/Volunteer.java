/**
 * @author: David Oswari
 * @version: 1.0
 * 
 * no new changes
 * volunteers don't get paid so getPaid() will return 0
 * this class allows negative numbers for ID and payRate
 **/

public class Volunteer extends StaffMember
{
     /**
   * @param ID
   * ID of Volunteer
   * 
   * @param firstName
   * first name of Volunteer
   * 
   * @param lastName
   * last name of Volunteer
   * 
   * @param payRate
   * payRate of Volunteer
   **/
   public Volunteer(int ID, String firstName, String lastName, double payRate)
   {
      super(ID,firstName,lastName,payRate);
   }
    /**
    *@return 0
    **/
   public double getPaid()
   {
      return 0;
   }
   
   /**
    * @return "Volunteer"
    **/
   public String employeeType()
   {
      return "Volunteer";
   }

}