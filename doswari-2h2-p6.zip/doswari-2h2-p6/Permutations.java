import java.util.ArrayList;

/**
 *@author: David Oswari
 *@version: 1.0
 *This program computes permutations of a wording.
 */
public class Permutations
{
   private static ArrayList<String> list;
   /**Takes a command line input from the user and prints all 
     * possible permutations of the entered word.
     * @param args user input for the wording to permute
     */	
   public static void main(String[] args)
   {
      list = permutations("eat");
      System.out.println(list);
   }

   /**
    *Gets all permutations of a given word.
    *@param word the wording to permute
    *@return a list of all permutations
    */
   public static ArrayList<String> permutations(String word)
   {
      ArrayList<String> list = new ArrayList<String>();
      permutation(list,"",word);
      return list;
   }
//helper method
   private static void permutation(ArrayList<String> list , String temp, String word) 
   {
      //add temp to list when word becomes empty
      if (word.length() == 0)
         list.add(temp);
        
      //put letters from word into temp
      else 
         for (int i = 0; i < word.length(); i++)
         {  
            permutation(list, temp + word.charAt(i), word.substring(0, i) + word.substring(i+1));
           
         }
   }
 
}

