import static org.junit.Assert.*;
import org.junit.Test;
import org.junit.*;

  /**
   * @author: David Oswari
   *
   * @version: 1.0;
   * 
   * this code tests all methods in Executive class
   * 
   **/

public class ExecutiveTest
{
private Executive barry,robin;
/**
 * sets up 2 Executives
 **/
@Before
public void setUp()
{
barry = new Executive(1200,"Barry","Allen",120000);
robin = new Executive(2000,"Robin" , "Lee", 150000);
}
/**
 * tests getFirstName
 **/
@Test
public void getFirstNameTest()
{
  assertTrue(robin.getFirstName().equals("Robin"));
  assertTrue(barry.getFirstName().equals("Barry"));
}
/**
 * tests getLastName method
 **/
@Test
public void getLastNameTest()
{
  assertTrue(robin.getLastName().equals("Lee"));
  assertTrue(barry.getLastName().equals("Allen"));
}

/**
 * tests getID method
 **/
@Test
public void getIDTest()
{
  assertTrue(robin.getID()==2000);
  assertTrue(barry.getID()==1200);
}
/**
 * tests getPayRate and setPayRate
 **/
@Test
public void getSetPayRate()
{
assertTrue(barry.getPayRate()==120000);
assertTrue(robin.getPayRate()==150000);
  
barry.setPayRate(12000);
robin.setPayRate(-400);
assertTrue(barry.getPayRate()==12000);
assertTrue(robin.getPayRate()==-400);
}

/**
 *tests getAdditionalBonus and setAdditionalBonus methods 
 **/
@Test
public void getSetAdditionalBonus()
{
barry.setAdditionalBonus(1500);
assertTrue(barry.getAdditionalBonus()==1500);  

barry.setAdditionalBonus(1200);
assertTrue(barry.getAdditionalBonus()==1200);  
}

/**
 * tests getPaid method without additional bonus
 **/
@Test
public void getPaidTest()
{  
assertTrue(barry.getPaid()==10100);
assertTrue(robin.getPaid()==12625);

}
/**
 * tests getPaid with additional bonus
 **/
@Test
public void getPaidBonusTest()
{
 barry.setAdditionalBonus(1500);
robin.setAdditionalBonus(2000);

assertTrue(barry.getPaid()==11600);
assertTrue(robin.getPaid()==14625);

assertTrue(barry.getAdditionalBonus()==0);
assertTrue(robin.getAdditionalBonus()==0);   
}

/**
 * checks employeeType
 **/
@Test
public void employeeTypeTest()
{
assertTrue(barry.employeeType().equals("Executive"));
assertTrue(robin.employeeType().equals("Executive"));
}
}