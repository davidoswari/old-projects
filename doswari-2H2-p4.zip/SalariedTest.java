import static org.junit.Assert.*;
import org.junit.Test;
import org.junit.*;

/**
 * @author: David Oswari
 * @version: 1.0
 * 
 * this code tests all methods in Salaried class
 **/ 

public class SalariedTest
{
private Salaried john,paul;
/**
 * sets up 2 Salaried
 **/
@Before
public void setUp()
{
john = new Salaried(2,"John","Smith",60000);
paul = new Salaried(-2,"Paul" , "Doe", -10800);
}
/**
 * tests the getFirstName method
 **/
@Test
public void getFirstNameTest()
{
  assertTrue(paul.getFirstName().equals("Paul"));
  assertTrue(john.getFirstName().equals("John"));
}
/**
 * tests the getLastName method
 **/

@Test
public void getLastNameTest()
{
  assertTrue(paul.getLastName().equals("Doe"));
  assertTrue(john.getLastName().equals("Smith"));
}

/**
 * tests the getID method
 **/
@Test
public void getIDTest()
{
  assertTrue(paul.getID()==-2);
  assertTrue(john.getID()==2);
}

/**
 *tests the getPayRate and setPayRate methods 
 **/
@Test
public void getSetPayRate()
{
assertTrue(john.getPayRate()==60000);
assertTrue(paul.getPayRate()==-10800);
  
john.setPayRate(12000);
paul.setPayRate(-400);
assertTrue(john.getPayRate()==12000);
assertTrue(paul.getPayRate()==-400);
}
/**
 * checks the getPaid Method
 **/
@Test
public void getPaidTest()
{  
assertTrue(john.getPaid()==5000);
assertTrue(paul.getPaid()==-900);
}

/**
 * checks that employeeYype method is correct
 **/
@Test
public void employeeTypeTest()
{
assertTrue(john.employeeType().equals("Salaried"));
assertTrue(paul.employeeType().equals("Salaried"));
}
}