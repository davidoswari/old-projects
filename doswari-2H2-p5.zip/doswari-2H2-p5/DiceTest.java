import static org.junit.Assert.*;
import org.junit.Test;
import org.junit.*;
/**
 * This class tests the Dice class's object states.
 * @author: David Oswari
 * @version: 1.0
 **/
public class DiceTest
{
 private Dice dice;

 @Before 
 public void setUp()
 {
   dice = new Dice();
 }
 
 @Test
 public void getValue1Test()
 {
   assertTrue(dice.getValue1()==1);
 }
 @Test
 public void getValue2Test()
 {
   assertTrue(dice.getValue2()==1); 
 }

 @Test
 public void getSumTest()
 {
   assertTrue(dice.getSum()==2);
 }
 
 @Test
 public void printSumTest()
 {
  assertTrue(dice.printSum().equals("1 + 1 = 2")); 
 }
 
 @Test
 public void hasOne()
 {
  assertTrue(dice.hasOne()==true); 
 }
}
