/**
 * @author: David Oswari
 * @version: 1.0
 * 
 * this code runs all tests
 **/
import org.junit.*;
import static org.junit.Assert.*;
import java.util.*;

public class P4Tests {
  public static void main(String args[]){
    org.junit.runner.JUnitCore.main("ExecutiveTest",
                                    "HourlyTest",
                                    "SalariedTest",
                                    "VolunteerTest", 
                                    "StaffDemoTest"
  );
  }
}
