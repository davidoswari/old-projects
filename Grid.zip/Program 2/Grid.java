//David Oswari
//The grid Class
public class Grid
{
   private int numberOfRows=1;
   private int numberOfColumns=1;
   private int printWidth=10;
   private Node head = new Node(new Value());
   
   //grid constructor
   public Grid()
   {
   //make head wrap around to itself
      head.next = head;
      head.down = head;
      
   //add 5 columns
      for(int i=0;i<5;i++)
         insertColumn(0);
   //add 9 rows
      for(int i=0;i<9;i++)
         insertRow(0);       
   }
   
   //inner class node
   private class Node 
   {
      Value value;
      Node next;
      Node down;
      
      //constructor
      public Node(Value v)
      {
         value = v;
      }
   }
 //finds a specific node at row and column
   private Node findNode(int row, int col)
   {
      Node p = head;
      
      //go down
      for(int i =0; i<row; i++)
         p = p.down;
      //go left
      for(int i = 0; i<col;i++)
         p = p.next;
         
      return p;
   }
   
   //this method changes the value in a node
   //this method is used when given a string.
   public void assignCell(int row, int col, String value)
   {
   //check row and col
      if(row>=numberOfRows || col >=numberOfColumns || row<0 || col<0)
      {
         System.out.println("out of range");
      }
      else
      {
         Node p = findNode(row,col);
         p.value.setValue(value);
      }
   }
   
   //this method also changes the value in a node
   //this method is used when given a value.
   public void assignCell(int row, int col, Value v)
   {
   //check row and col
      if(row>=numberOfRows || col >=numberOfColumns || row<0 || col<0)
      {
         System.out.println("out of range");
      }
      else
      {
         Node p = findNode(row,col);
         p.value = v;
      }
   }
   
   public void fill(int row1, int col1, int row2, int col2, String value)
   {
      if(row1>=numberOfRows || col1>=numberOfColumns || row2>=numberOfRows || col2 >=numberOfColumns
      ||row1<0 || col1<0 || row2<0 || col2<0)
      {
         System.out.println("out of range");
      }
      else
      {
         for(int i=row1;i<=row2;i++)
         {
            for(int j = col1; j<=col2; j++)
            {
               assignCell(i,j,value);
            }
         }
      }
   }
   
   //inserts after target row
   public void insertRow(int row)
   {
      if(row>=numberOfRows || row<0)
      {
         System.out.println("out of range");
      }
      else
         for(int c=0;c<numberOfColumns;c++)
         {
            Node newNode = new Node(new Value());
            Node up = findNode(row,c);
            Node left = findNode(row+1,c-1); 
                
            //new node down pointer
            newNode.down = up.down;  
            up.down = newNode;
            
            //node left of new node next pointer
            if(c!=0 && left!=null)
            {
               newNode.next = left.next;
               left.next = newNode;
            } 
         }
      numberOfRows++;
      wrapAround(); 
   }
   
   //this method is used to insert a new first row (insert after -1)
   public void insertFirstRow()
   {
      insertRow(0);
      swapRows(0,1);
   }
   public void insertFirstColumn()
   {
      insertColumn(0);
      swapColumns(0,1);
   }
   
   //inserts after target col
   public void insertColumn(int col)
   {
   //check col
      if(col >=numberOfColumns || col<0)
      {
         System.out.println("out of range");
      }
      else
      {
         for(int r=0;r<numberOfRows;r++)
         {
            Node newNode = new Node(new Value());
            Node up = findNode(r-1,col+1);
            Node left = findNode(r,col);
         
            newNode.next = left.next;
            if(r!=0 && up!=null)
            {
               newNode.down = up.down;
               up.down = newNode;
            
            }
            left.next = newNode;
         }
         numberOfColumns++;
         wrapAround();
      }
   }
   //this method is used for inserting after -1;

   public static void main(String[] args)
   {
      Grid grid = new Grid();
   }
   //method swaps values between rows
   public void swapRows(int row1, int row2)
   {
      for(int c=0;c<numberOfColumns;c++)
      {
         Node one = findNode(row1,c);
         Node two = findNode(row2,c);
         Value temp = one.value;
         one.value = two.value;
         two.value = temp; 
      }
   }
   //method swaps values between columns
   public void swapColumns(int col1, int col2)
   {
      for(int r=0;r<numberOfRows;r++)
      {
         Node one = findNode(r,col1);
         Node two = findNode(r,col2);
         Value temp = one.value;
         one.value = two.value;
         two.value = temp; 
      }
   }
   
   //this method fixes the wrap around on the ends of the grid
   public void wrapAround()
   {
      for(int r=0;r<numberOfRows;r++)
      {
         for(int c=0;c<numberOfColumns;c++)
         {
         //right most node in row
            Node a = findNode(r,numberOfColumns-1);
         //bottom node in column
            Node b = findNode(numberOfRows-1, c);
         
            a.next = findNode(r,0);
            b.down = findNode(0,c);
         }
      }
   }
   
   //this method deletes a target row
   public void deleteRow(int row)
   {
      //check row
      if(row>=numberOfRows || row<0)
      {
         System.out.println("out of range");
      }
      else
      {
         if(numberOfRows>1)
         {
         //special case, first row
            if(row==0)
               head = head.down;
            
            else
               for(int c=0;c<numberOfColumns;c++)
               {
               //find node above and skip a row
                  Node p = findNode(row-1,c);
                  p.down = p.down.down;
               }
            numberOfRows--;
         }
      }
   }
   //this method deletes a target column
   public void deleteColumn(int col)
   {
      //check col
      if(col >=numberOfColumns || col<0)
      {
         System.out.println("out of range");
      }
      else
      {
         if(numberOfColumns>1)
         {
         //special case first col
            if(col==0)
               head = head.next;
            else
               for(int r=0;r<numberOfRows;r++)
               {
               //find node before and skip a column
                  Node p = findNode(r,col-1);
                  p.next = p.next.next;
               }
            numberOfColumns--;
         }
      }
   }

  //adds two nodes together, and returns a Value
   public Value addCells(int row1, int col1, int row2, int col2)
   {
      Node one = findNode(row1,col1);
      Node two = findNode(row2,col2);
      Value v = one.value.addValue(two.value);
      return v;
   }
   
   //subtracts two nodes, and returns a Value
   public Value subtractCells(int row1, int col1, int row2, int col2)
   {
      Node one = findNode(row1,col1);
      Node two = findNode(row2,col2);
      Value v = one.value.subtractValue(two.value);
      return v;
   }
   //multiplies two nodes, and returns a Value
   public Value multiplyCells(int row1, int col1, int row2, int col2)
   {
      Node one = findNode(row1,col1);
      Node two = findNode(row2,col2);
      Value v = one.value.multiplyValue(two.value);
      return v;
   
   }
//divides two nodes, and returns a Value
   public Value divideCells(int row1, int col1, int row2, int col2)
   {
      Node one = findNode(row1,col1);
      Node two = findNode(row2,col2);
      Value v = one.value.divideValue(two.value);
      return v;
   
   }
      
   public void printGrid()
   {
   //print the column numbers at top
      System.out.printf("%10s","");
      for(int c = 0; c <  numberOfColumns; c++)
         System.out.printf("%1$-10s","column " + c);
      System.out.printf("\n");
     
      for(int r=0;r< numberOfRows;r++)
      {
      //print row numbers
         System.out.printf("%1$-10s", "row " + r);
         for(int c=0;c< numberOfColumns;c++)
         {
         //print value
            Node  p = findNode(r,c);
            System.out.printf("%1$-10s", formatString(p.value.toString()));
         }
         System.out.printf("\n");
      }
   
   }
   //numbers the cells between two cells, making a box
   public void numberCells(int row, int col, int row2, int col2)
   {
   //check values
      if(row>=numberOfRows || col >=numberOfColumns   || row2>=numberOfRows || col2 >=numberOfColumns
      ||row<0 || col<0   || row2<0 || col2<0)
      {
         System.out.println("out of range");
      }
      else
      {
         Node p;
         double d=0;
      
         for(int r=row;r<=row2;r++)
         {
            for(int c=col;c<=col2;c++)
            {
            //visit every node
               p = findNode(r,c);
            //set the Value of node to d
               p.value.setValue(""+d);
               d++;
            }
         }
      }
   }
   //adds two rows and puts the sums in the target row
   public void addRows(int row1, int row2, int targetRow)
   {
   //check values
      if(row1>=numberOfRows || row2 >=numberOfRows || targetRow >=numberOfRows || row1<0 ||row2<0 ||targetRow<0)
      {
         System.out.println("out of range");
      }
      else
      {
         for(int i=0;i<numberOfColumns;i++)
         {
         //node in first row
            Node one = findNode(row1,i);
         //node in second row
            Node two = findNode(row2,i);
            Value v = one.value.addValue(two.value);
         //put in node if not invalid
            if(v.tag!=2)
               assignCell(targetRow,i,v);
         }
      }
   }
   //subtracts two rows and puts the differences in the target row
   public void subtractRows(int row1, int row2, int targetRow)
   {
   //check values
      if(row1>=numberOfRows || row2 >=numberOfRows || targetRow >=numberOfRows || row1<0 ||row2<0 ||targetRow<0)
      {
         System.out.println("out of range");
      }
      else
      {
         for(int i=0;i<numberOfColumns;i++)
         {
         //node in first row
            Node one = findNode(row1,i);
         //node in second row
            Node two = findNode(row2,i);
            Value v = one.value.subtractValue(two.value);
         //put in node if not invalid
            if(v.tag!=2)
               assignCell(targetRow,i,v);
         }
      }
   }
   //multiplys two rows and puts the products in target row
   public void multiplyRows(int row1, int row2, int targetRow)
   {
   //check values
      if(row1>=numberOfRows || row2 >=numberOfRows || targetRow >=numberOfRows || row1<0 ||row2<0 ||targetRow<0)
      {
         System.out.println("out of range");
      }
      else
      {
         for(int i=0;i<numberOfColumns;i++)
         {
         //node in first row
            Node one = findNode(row1,i);
         //node in second row
            Node two = findNode(row2,i);
            Value v = one.value.multiplyValue(two.value);
         //put in node if not invalid
            if(v.tag!=2)
               assignCell(targetRow,i,v);
         }
      }
   }
   //divides two rows and puts the quotients in target row
   public void divideRows(int row1, int row2, int targetRow)
   {
   //check values
      if(row1>=numberOfRows || row2 >=numberOfRows || targetRow >=numberOfRows || row1<0 ||row2<0 ||targetRow<0)
      {
         System.out.println("out of range");
      }
      else
      {
         for(int i=0;i<numberOfColumns;i++)
         {
         //node in first row
            Node one = findNode(row1,i);
         //node in second row
            Node two = findNode(row2,i);
            Value v = one.value.divideValue(two.value);
         //put in node if not invalid
            if(v.tag!=2)
               assignCell(targetRow,i,v);
         }
      }
   }
   //adds two columns and puts the sums in target column
   public void addColumns(int col1, int col2, int targetCol)
   {
   //check values
      if(col1>=numberOfColumns || col2 >=numberOfColumns || targetCol >=numberOfColumns || col1<0 ||col2<0 ||targetCol<0)
      {
         System.out.println("out of range");
      }
      else
      {
         for(int i=0;i<numberOfRows;i++)
         {
         //node in first row
            Node one = findNode(i,col1);
         //node in second row
            Node two = findNode(i,col2);
            Value v = one.value.addValue(two.value);
         //put in node if not invalid
            if(v.tag!=2)
               assignCell(i,targetCol,v);
         }
      }
   }
   //subtracts two columns and puts the differences in target column
   public void subtractColumns(int col1, int col2, int targetCol)
   {
   //check values
      if(col1>=numberOfColumns || col2 >=numberOfColumns || targetCol >=numberOfColumns || col1<0 ||col2<0 ||targetCol<0)
      {
         System.out.println("out of range");
      }
      else
      {
         for(int i=0;i<numberOfRows;i++)
         {
         //node in first row
            Node one = findNode(i,col1);
         //node in second row
            Node two = findNode(i,col2);
            Value v = one.value.subtractValue(two.value);
         //put in node if not invalid
            if(v.tag!=2)
               assignCell(i,targetCol,v);
         }
      }
   }
   //multiplies two columns and puts the products in target column
   public void multiplyColumns(int col1, int col2, int targetCol)
   {
   //check values
      if(col1>=numberOfColumns || col2 >=numberOfColumns || targetCol >=numberOfColumns || col1<0 ||col2<0 ||targetCol<0)
      {
         System.out.println("out of range");
      }
      else
      {
         for(int i=0;i<numberOfRows;i++)
         {
         //node in first row
            Node one = findNode(i,col1);
         //node in second row
            Node two = findNode(i,col2);
            Value v = one.value.multiplyValue(two.value);
         //put in node if not invalid
            if(v.tag!=2)
               assignCell(i,targetCol,v);
         }
      }
   }

//divides two columns and puts the quotients in target column
   public void divideColumns(int col1, int col2, int targetCol)
   {
   //check values
      if(col1>=numberOfColumns || col2 >=numberOfColumns || targetCol >=numberOfColumns || col1<0 ||col2<0 ||targetCol<0)
      {
         System.out.println("out of range");
      }
      else
      {
         for(int i=0;i<numberOfRows;i++)
         {
         //node in first row
            Node one = findNode(i,col1);
         //node in second row
            Node two = findNode(i,col2);
            Value v = one.value.divideValue(two.value);
         //put in node if not invalid
            if(v.tag!=2)
               assignCell(i,targetCol,v);
         }
      }
   }
   
   //returns a string whose length is less than printWidth
   public String formatString(String str)
   {
      if(str.length()>printWidth)
         return str.substring(0,printWidth);
      return str;
   }







   
   
   
}