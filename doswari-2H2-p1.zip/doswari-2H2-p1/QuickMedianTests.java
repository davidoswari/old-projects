// Example of using unit tests for programming assignment 1.  This is
// partially how your code will be graded.  Later in the class we will
// write our own unit tests.  To run them on the command line, make
// sure that the junit-cs211.jar is in the project directory.
// 
// $> javac -cp .:junit-cs211.jar QuickMedianTests.java   #compile
// $> java -cp .:junit-cs211.jar QuickMedianTests         #run tests
// 
// On windows replace : with ; (colon with semicolon)
// $> javac -cp .;junit-cs211.jar QuickMedianTests.java   #compile
// $> java -cp .;junit-cs211.jar QuickMedianTests         #run tests

import org.junit.*;
import static org.junit.Assert.*;
import java.util.*;

public class QuickMedianTests {
   public static void main(String args[]){
      org.junit.runner.JUnitCore.main("QuickMedianTests");
   }
   
   // Test whether partition works as advertised. This test
   void test_partition(int [] a, int left, int right, int pivotIndex){
      int [] orig = Arrays.copyOf(a, a.length);
      int pivot = a[pivotIndex];
      int boundary = QuickMedian.partition(a,left,right,pivotIndex);
      String error = "";
      for(int i=left; i<=right; i++){
         if(i < boundary && a[i] > pivot){
            error = String.format("Left side element a[%d]=%d larger than pivot=%d",
                                   i,a[i],pivot);
            break;
         }
         else if(i == boundary && a[i] != pivot){
            error = String.format("Boundary element a[%d]=%d should be pivot=%d",
                                   i,a[i],pivot);
            break;
         }
         else if(i > boundary && a[i] < pivot) { 
            error = String.format("Right side element a[%d]=%d smaller than pivot=%d",
                                   i,a[i],pivot);
            break;
         }
      }
      if(!error.equals("")){
         String msg = "";
         msg += String.format("%s\noriginal: %s\nleft,right: %d %d\npivotIndex: %d\npivot: %d\n",
                               error,Arrays.toString(orig),left,right,pivotIndex,pivot);
         msg += String.format("partitioned: %s\nboundary: %d\n",Arrays.toString(a),boundary);
         fail(msg);
      }
   }

   // Test whether quickMedian works as advertised. This should
   // partition the array around the median (index n/2).  
   void test_quickMedian(int [] a, int expect){
      int [] orig = Arrays.copyOf(a, a.length);
      int [] sorted = Arrays.copyOf(a, a.length);
      Arrays.sort(sorted);
      int actual = QuickMedian.quickMedian(a);
      int boundary = a.length/2;
      String error = "";
      if(actual != expect){
         error = String.format("Median does not match expected\nexpect: %d\nactual: %d\n",
                                expect,actual);
      }
      for(int i=0; i<a.length && error.equals(""); i++){
         if(i < boundary && a[i] > actual){
            error = String.format("Left side element a[%d]=%d larger than median=%d",
                                   i,a[i],actual);
         }
         else if(i == boundary && a[i] != actual){
            error = String.format("Median element a[%d]=%d should be median=%d",
                                   i,a[i],actual);
         }
         else if(i > boundary && a[i] < actual) { 
            error = String.format("Right side element a[%d]=%d smaller than median=%d",
                                   i,a[i],actual);
         }
      }
      if(!error.equals("")){
         String msg = "";
         msg += String.format("%s\noriginal: %s\n\n", error,Arrays.toString(orig));
         msg += String.format("mutated:  %s\nsorted:   %s\n",Arrays.toString(a),Arrays.toString(sorted));
         fail(msg);
      }
   }


   @Test (timeout=1000) public void QuickMedian_partition_01(){
      int a[] = { 8, 6, 7, 5, 3, 0, 9};
      test_partition(a, 0, a.length-1, 2);
   }
   @Test (timeout=1000) public void QuickMedian_partition_02(){
      int a[] = { 8, 6, 7, 5, 3, 0, 9};
      test_partition(a, 0, a.length-1, 3);
   }
   @Test (timeout=1000) public void QuickMedian_partition_03(){
      int a[] = { 8, 6, 7, 5, 3, 0, 9};
      test_partition(a, 0, a.length-1, 0);
   }
   @Test (timeout=1000) public void QuickMedian_partition_04(){
      int a[] = {1, 9, 2, 3};
      test_partition(a, 0, a.length-1, 0);
   }
   @Test (timeout=1000) public void QuickMedian_partition_05(){
      int a[] = {1, 9, 2, 3};
      test_partition(a, 0, a.length-1, 1);
   }
   @Test (timeout=1000) public void QuickMedian_partition_06(){
      int a[] = {1, 9, 2, 3};
      test_partition(a, 0, a.length-1, 1);
   }
   @Test (timeout=1000) public void QuickMedian_partition_07(){
      int a[] = {1, 9, 2, 3, 8};
      test_partition(a, 0, a.length-1, 0);
   }
   @Test (timeout=1000) public void QuickMedian_partition_08(){
      int a[] = {1, 9, 2, 3, 8};
      test_partition(a, 0, a.length-1, 1);
   }
   @Test (timeout=1000) public void QuickMedian_partition_09(){
      int a[] = {1, 9, 2, 3, 8};
      test_partition(a, 0, a.length-1, 2);
   }
   @Test (timeout=1000) public void QuickMedian_partition_10(){
      int a[] = {1, 9, 2, 3, 8};
      test_partition(a, 0, a.length-1, 3);
   }
   @Test (timeout=1000) public void QuickMedian_partition_11(){
      int a[] = {2, 5, 6, 7, 4, 5, 3, 15, 1, 1, 16, 15, 13, };
      test_partition(a, 0, a.length-1, 0);
   }
   @Test (timeout=1000) public void QuickMedian_partition_12(){
      int a[] = {2, 5, 6, 7, 4, 5, 3, 15, 1, 1, 16, 15, 13, };
      test_partition(a, 0, a.length-1, 1);
   }
   @Test (timeout=1000) public void QuickMedian_partition_13(){
      int a[] = {2, 5, 6, 7, 4, 5, 3, 15, 1, 1, 16, 15, 13, };
      test_partition(a, 0, a.length-1, 4);
   }
   @Test (timeout=1000) public void QuickMedian_partition_14(){
      int a[] = {2, 5, 6, 7, 4, 5, 3, 15, 1, 1, 16, 15, 13, };
      test_partition(a, 0, a.length-1, a.length-1);
   }
   @Test (timeout=1000) public void QuickMedian_partition_15(){
      int a[] = {2, 5, 6, 7, 4, 5, 3, 15, 1, 1, 16, 15, 13, };
      test_partition(a, 0, a.length-1, a.length-2);
   }
   
   @Test (timeout=1000) public void QuickMedian_partition_range_01(){
      int a[] = {8, 4, 2, 3, 9, 1, -1, -1, -1, -1};
      test_partition(a, 0, 4, 1);
   }
   @Test (timeout=1000) public void QuickMedian_partition_range_02(){
      int a[] = {99, 99, 99, 99, 8, 4, 2, 3, 9, 1, };
      test_partition(a, 4, a.length-1, 5);
   }
   @Test (timeout=1000) public void QuickMedian_partition_range_03(){
      int a[] = {99, 99, 99, 99, 8, 4, 2, 3, 9, 1, -1, -1, -1, -1};
      test_partition(a, 4, 9, 5);
   }
   @Test (timeout=1000) public void QuickMedian_partition_range_04(){
      int a[] = {99, 99, 99, 99, 99, 7, 8, 4, 2, 3, 9, 1, -1, -1, -1, -1, -1};
      test_partition(a, 5, 11, 9);
   }

   @Test (timeout=1000) public void QuickMedian_quickMedian_singleton(){
      int a[] = {5,};
      test_quickMedian(a,5);
   }

   @Test (timeout=1000) public void QuickMedian_quickMedian_01(){
      int a[] = {2, 5, 6};
      test_quickMedian(a,5);
   }
   @Test (timeout=1000) public void QuickMedian_quickMedian_02(){
      int a[] = {2, 6, 5};
      test_quickMedian(a,5);
   }
   @Test (timeout=1000) public void QuickMedian_quickMedian_03(){
      int a[] = {6, 5, 2};
      test_quickMedian(a,5);
   }
   @Test (timeout=1000) public void QuickMedian_quickMedian_04(){
      int a[] = {6, 5, 2, 4};
      test_quickMedian(a,5);
   }
   @Test (timeout=1000) public void QuickMedian_quickMedian_05(){
      int a[] = {6, 4, 5, 2};
      test_quickMedian(a,5);
   }
   @Test (timeout=1000) public void QuickMedian_quickMedian_06(){
      int a[] = {2, 5, 6, 7, 4, 5, 3, 15, 1, 1, 16, 15, 13, };
      test_quickMedian(a,5);
   }
   @Test (timeout=1000) public void QuickMedian_quickMedian_07(){
      int a[] = {2, 5, 6, 7, 4, 5, 3, 15, 1, 1, 16, 15, 13, 9};
      test_quickMedian(a,6);
   }
   @Test (timeout=1000) public void QuickMedian_quickMedian_08(){
      int a[] = {5, 6, 7, 4, 21, 5, 3, 15, 14, 11, 15, 13, 9};
      test_quickMedian(a,9);
   }
   @Test (timeout=1000) public void QuickMedian_quickMedian_09(){
      int a[] = {6, 7, 21, 5, 3, 15, 5, 14, 15, 4, 13, 9, 11};
      test_quickMedian(a,9);
   }
   @Test (timeout=1000) public void QuickMedian_quickMedian_10(){
      int a[] = {92, 59, 56, 2, 20, 55, 23, 26, 1, 89, 99, 34, 26, 7, 64, 58, 78, 39, 29, 99, 24, 81, 75, 81, 21, 50, 27, 65, 60, 26, 38, 42, 81, 7, 86, 30, 23, 74, 25, 1, 25, 50, 20, 8, 53, 90, 21, 15, 28, 37, };
      test_quickMedian(a,38);
   }
}