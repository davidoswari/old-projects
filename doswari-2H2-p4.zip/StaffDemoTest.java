import static org.junit.Assert.*;
import org.junit.Test;
import org.junit.*;
import student.TestCase;
/**
 * @author: David Oswari
 * @version: 1.0
 * 
 * this code tests all StaffDemo methods, including main method
 **/ 
public class StaffDemoTest extends TestCase
{
  private StaffMember[] cStaff;
 /**
 * sets up cStaff 
 **/    
@Before
public void setUp()
{
 cStaff = StaffDemo.createStaff();
}
/**
 * tests the main method in StaffDemo
 * main method prints the result of payAll if all Hourly in cStaff work 0 hours or 80 hours 
 **/
@Test
public void mainTest()
{
  StaffDemo.main(null);
  String output = systemOut().getHistory();
  assertTrue(output.contains("Grace Hopper (Salaried) : $10000.00\n" + "James Gosling (Volunteer) : $0.00\n" +  
               "Dennis Ritchie (Hourly) : $680.00\n" + "Donald Knuth (Executive) : $28616.67\n"));
  
}

/**
 *checks to see if ID , FirstName, LastName, and payRate are correct
 * compares with information in found in staff.txt
 **/
@Test
public void createStaffTest()
{
assertTrue(cStaff[0].getID()==1);
assertTrue(cStaff[1].getID()==892);
assertTrue(cStaff[2].getID()==9765);
assertTrue(cStaff[3].getID()==5657);

assertTrue(cStaff[0].getFirstName().equals("Grace"));
assertTrue(cStaff[1].getFirstName().equals("James"));
assertTrue(cStaff[2].getFirstName().equals("Dennis"));
assertTrue(cStaff[3].getFirstName().equals("Donald"));

assertTrue(cStaff[0].getLastName().equals("Hopper"));
assertTrue(cStaff[1].getLastName().equals("Gosling"));
assertTrue(cStaff[2].getLastName().equals("Ritchie"));
assertTrue(cStaff[3].getLastName().equals("Knuth"));

assertTrue(cStaff[0].getPayRate()==120000);
assertTrue(cStaff[1].getPayRate()==0);
assertTrue(cStaff[2].getPayRate()==8.5);
assertTrue(cStaff[3].getPayRate()==340000);
}

/**
 * checks that payAll method prints the desired output
 * this method was used in the main method in StaffDemo
 **/
@Test
public void payallTest()
{
  StaffDemo.main(null);
  String output = systemOut().getHistory();
  assertTrue(output.contains("Grace Hopper (Salaried) : $10000.00\n" + "James Gosling (Volunteer) : $0.00\n" +  
               "Dennis Ritchie (Hourly) : $0.00\n" + "Donald Knuth (Executive) : $28616.67\n"));
}
/**
 * checks that formatNumber method works as intended
 **/
@Test
public void formatNumberTest()
{
  double num = 3.1415;
  assertEquals(StaffDemo.formatNumber(num),"3.14");
  
  double num2 = 3.145;
  assertEquals(StaffDemo.formatNumber(num2),"3.15");
}
}