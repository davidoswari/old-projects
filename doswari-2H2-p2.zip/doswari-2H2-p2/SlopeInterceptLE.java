// Fill in the definition for this class
public class SlopeInterceptLE {
   // Fields required for the class
   private double x=0;
   private double m=0;
   private double b=0;
   private double y=0;
   
   // Fill in the definitions of all methods
   public SlopeInterceptLE(double m, double b){
      this.m = m;
      this.b = b;
      this.y = m*x + b;
   }

   public SlopeInterceptLE(double m, double b, double x){
      this.m=m;
      this.b=b;
      this.x=x;
      this.y = m*x + b;
   
   }

   public double value(){
      return y;
   }
   
   public double getX(){
      return x;
   }
   public double getY(){
      return y;
   }

   public void setX(double x){
      this.x = x;
      y = m*x+b; // if x changes, y changes
   }
   public void setY(double y){
      this.y=y;
      x = (y-b)/m; // if y changes, x must change as well
   }

   public String toString()
   {
      return "y = " + formatNumber(m) +" * x + " + formatNumber(b);
   }
   public String formatNumber(double num)
   {
      return String.format( "%.2f", num ); // formats num to two decimal places
     
   }

}
