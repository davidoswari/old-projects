import org.junit.*;
import static org.junit.Assert.*;
import java.util.*;

public class CircularQueueTests {
  public static void main(String args[]){
    org.junit.runner.JUnitCore.main("CircularQueueTests");
  }
  
  /*
   building queues:
   - build small empty queue.   (2)
   - build larger empty queue. (11)
   - build length-zero queue.   (0)
   
   */  
  @Test(timeout=1000) public void CircularQueue_makeQueue_1(){
    String expected = "";
    CircularQueue q = new CircularQueue(2);
    String actual = q.toString();
    assertEquals(2, q.getCapacity());
    assertEquals(expected, actual);
  }
  @Test(timeout=1000) public void CircularQueue_makeQueue_2(){
    String expected = "";
    CircularQueue q = new CircularQueue(11);
    String actual = q.toString();
    assertEquals(11, q.getCapacity());
    assertEquals(expected, actual);
  }
  // on 0 or less initial capacity, choose 1
  @Test(timeout=1000) public void Queue_makeQueue_3(){
    String expected = "";
    CircularQueue q = new CircularQueue(0);
    String actual = q.toString();
    assertEquals(1, q.getCapacity());
    assertEquals(expected, actual);
  }
  @Test(timeout=1000) public void Queue_makeQueue_4(){
    String expected = "";
    CircularQueue q = new CircularQueue(-2);
    String actual = q.toString();
    assertEquals(1, q.getCapacity());
    assertEquals(expected, actual);
  }
  /*
   add/offer tests.
   - add a single value to a short queue.
   - fill up a small queue.
   - over-add to a queue and witness it struggle.
   - add many but don't finish filling a queue.
   - make size-zero queue, adds fail, check it's still empty.
   */
  @Test(timeout=1000) public void CircularQueue_add_1(){
    String expected = "5";
    CircularQueue q = new CircularQueue(3);
    boolean ans = q.add(5);
    String actual = q.toString();
    assertTrue(ans);
    assertEquals(1, q.getSize());
    assertEquals(expected, actual);
  }
  @Test(timeout=1000) public void CircularQueue_add_2(){
    CircularQueue q = new CircularQueue(3);
    
    boolean ans;
    ans = q.add(5);
    assertTrue(ans);
    
    ans = q.add(12);
    assertTrue(ans);
    
    ans = q.add(99);
    assertTrue(ans);
    
    String expected = "5 12 99";
    String actual = q.toString();
    assertEquals(3, q.getSize());
    assertEquals(expected, actual);
  }
  
  
  @Test(timeout=1000) public void CircularQueue_add_3(){
    
    CircularQueue q = new CircularQueue(3);
    boolean ans;

    ans = q.add(5);
    assertTrue(ans);
    
    ans = q.add(12);
    assertTrue(ans);
    
    ans = q.add(99);
    assertTrue(ans);
    
    // expand size
    ans = q.add(22);
    assertTrue(ans);

    ans = q.add(11);
    assertTrue(ans);
    
    assertEquals(5, q.getSize());
    assertEquals("5 12 99 22 11", q.toString());
    assertEquals(6, q.getCapacity());
  }
  
  
  @Test(timeout=1000) public void CircularQueue_add_4(){
    CircularQueue q = new CircularQueue(0);
    assertEquals(0, q.getSize());
    assertEquals(1, q.getCapacity());

    assertTrue(q.add(5));

    assertEquals(1, q.getSize());
    assertEquals(1, q.getCapacity());
    assertEquals("5", q.toString());
  }
  
  
  @Test(timeout=1000) public void CircularQueue_offer_1(){
    String expected = "5";
    CircularQueue q = new CircularQueue(3);
    q.offer(5);
    String actual = q.toString();
    assertEquals(1, q.getSize());
    assertEquals(expected, actual);
  }
  @Test(timeout=1000) public void CircularQueue_offer_2(){
    String expected = "5 12 99";
    CircularQueue q = new CircularQueue(3);
    q.offer(5);
    q.offer(12);
    q.offer(99);
    String actual = q.toString();
    assertEquals(3, q.getSize());
    assertEquals(expected, actual);
  }
  
  
  @Test(timeout=1000) public void CircularQueue_offer_3(){
    CircularQueue q = new CircularQueue(3);
    boolean ans;
    ans = q.offer(5);
    assertTrue(ans);
    ans = q.offer(12);
    assertTrue(ans);
    ans = q.offer(99);
    assertTrue(ans);

    // Expand
    ans = q.offer(33);
    assertTrue(ans);
    
    assertEquals(4, q.getSize());
    assertEquals(6, q.getCapacity());
    assertEquals("5 12 99 33", q.toString());

    assertTrue(q.offer(11));
    assertTrue(q.offer(22));

    assertEquals(6, q.getSize());
    assertEquals(6, q.getCapacity());
    assertEquals("5 12 99 33 11 22", q.toString());

    // Expand
    assertTrue(q.offer(13));
    assertTrue(q.offer(89));

    assertEquals(8, q.getSize());
    assertEquals(12, q.getCapacity());
    assertEquals("5 12 99 33 11 22 13 89", q.toString());
  }
  
  
  // Defaul to capacity 1
  @Test(timeout=1000) public void CircularQueue_offer_4(){
    CircularQueue q = new CircularQueue(-4);
    assertTrue(q.offer(5));
    
    assertEquals(1, q.getSize());
    assertEquals(1, q.getCapacity());
    assertEquals("5", q.toString());

    assertTrue(q.offer(15));
    assertEquals(2, q.getSize());
    assertEquals(2, q.getCapacity());
    assertEquals("5 15", q.toString());

    assertTrue(q.offer(25));
    assertEquals(3, q.getSize());
    assertEquals(4, q.getCapacity());
    assertEquals("5 15 25", q.toString());

    assertTrue(q.offer(35));
    assertTrue(q.offer(45));
    assertEquals(5, q.getSize());
    assertEquals(8, q.getCapacity());
    assertEquals("5 15 25 35 45", q.toString());
  }
  
  
  /*
   remove/poll tests.
   - remove the one elt, check queue is empty.
   - remove one of few elts, check rest are there and correctly placed.
   - remove all, check it's now empty.
   - try to remove too many, see it struggle.
   */
  @Test(timeout=1000) public void CircularQueue_remove_1(){
    CircularQueue q = new CircularQueue(3);
    Integer v1 = 17;
    q.add(v1);
    Integer ans = q.remove();
    assertEquals(v1,ans);
    assertTrue(q.isEmpty());
    assertFalse(q.isFull());
  }
  
  @Test(timeout=1000) public void CircularQueue_remove_2(){
    CircularQueue q = new CircularQueue(5);
    Integer v1 = 10, v2=12, v3=14, v4=16;
    q.add(v1);
    q.add(v2);
    q.add(v3);
    q.add(v4);
    
    Integer ans = q.remove();
    assertEquals(v1,ans);
    
    assertEquals("12 14 16", q.toString());
    assertFalse(q.isFull());
  }
  
  @Test(timeout=1000) public void CircularQueue_remove_3(){
    CircularQueue q = new CircularQueue(5);
    Integer v1 = 10, v2=12, v3=14, v4=16;
    q.add(v1);
    q.add(v2);
    q.add(v3);
    q.add(v4);
    
    Integer ans;
    ans = q.remove();
    assertEquals(v1,ans);
    
    ans = q.remove();
    assertEquals(v2,ans);
    
    ans = q.remove();
    assertEquals(v3,ans);
    
    ans = q.remove();
    assertEquals(v4,ans);
    
    
    assertEquals("", q.toString());
    assertTrue(q.isEmpty());
    assertFalse(q.isFull());
  }
  
  
  @Test(timeout=1000) public void CircularQueue_remove_4(){
    CircularQueue q = new CircularQueue(3);
    
    // nothing to remove!
    try {
      q.remove();
      fail ("should have raised exception: nothing to remove.");
    } catch (RuntimeException e) {
      assertEquals("Queue empty",e.getMessage());
    }
    
    assertEquals("", q.toString());
    assertTrue(q.isEmpty());
    assertFalse(q.isFull());
  }
  
  
  @Test(timeout=1000) public void CircularQueue_remove_5(){
    CircularQueue q = new CircularQueue(3);
    Integer v1 = 10, v2=12, v3=14;
    q.add(v1);
    q.add(v2);
    q.add(v3);
    
    Integer ans;
    ans = q.remove();
    assertEquals(v1,ans);
    
    ans = q.remove();
    assertEquals(v2,ans);
    
    ans = q.remove();
    assertEquals(v3,ans);
    
    // nothing left to remove!
    try {
      ans = q.remove();
      fail ("should have raised exception: nothing to remove.");
    } catch (RuntimeException e) { 
      assertEquals("Queue empty",e.getMessage());
    }
    
    assertEquals("", q.toString());
    assertTrue(q.isEmpty());
    assertFalse(q.isFull());
  }
  
  
  
  @Test(timeout=1000) public void CircularQueue_poll_1(){
    CircularQueue q = new CircularQueue(3);
    Integer v1 = 17;
    q.add(v1);
    
    Integer ans = q.poll();
    assertEquals(v1,ans);
    
    assertTrue(q.isEmpty());
    assertFalse(q.isFull());
  }
  
  @Test(timeout=1000) public void CircularQueue_poll_2(){
    CircularQueue q = new CircularQueue(5);
    Integer v1 = 10, v2=12, v3=14, v4=16;
    
    q.add(v1);
    q.add(v2);
    q.add(v3);
    q.add(v4);
    
    Integer ans = q.poll();
    assertEquals(v1,ans);
    
    assertEquals("12 14 16", q.toString());
    assertFalse(q.isFull());
  }
  
  @Test(timeout=1000) public void CircularQueue_poll_3(){
    CircularQueue q = new CircularQueue(5);
    Integer v1 = 10, v2=12, v3=14, v4=16;
    q.add(v1);
    q.add(v2);
    q.add(v3);
    q.add(v4);
    
    Integer ans;
    ans = q.poll();
    assertEquals(v1,ans);
    
    ans = q.poll();
    assertEquals(v2,ans);
    
    ans = q.poll();
    assertEquals(v3,ans);
    
    ans = q.poll();
    assertEquals(v4,ans);
    
    
    assertEquals("", q.toString());
    assertTrue(q.isEmpty());
    assertFalse(q.isFull());
  }
  
  
  @Test(timeout=1000) public void CircularQueue_poll_4(){
    CircularQueue q = new CircularQueue(3);
    
    // nothing to poll!
    Integer ans = q.poll();
    assertEquals(null, ans);
    
    assertEquals("", q.toString());
    assertTrue(q.isEmpty());
    assertFalse(q.isFull());
  }
  
  
  @Test(timeout=1000) public void CircularQueue_poll_5(){
    CircularQueue q = new CircularQueue(3);
    Integer v1 = 10, v2=12, v3=14;
    q.add(v1);
    q.add(v2);
    q.add(v3);
    
    Integer ans;
    ans = q.poll();
    assertEquals(v1,ans);
    
    ans = q.poll();
    assertEquals(v2,ans);
    
    ans = q.poll();
    assertEquals(v3,ans);
    
    // nothing left to poll!
    ans = q.poll();
    assertEquals(null,ans);
    
    assertEquals("", q.toString());
    assertTrue(q.isEmpty());
    assertFalse(q.isFull());
  }
  
  
  /*
   element/peek tests.
   - peek at empty queue, see it struggle.
   - peek at the only item; check it's still there.
   - peek at first of many; check they're all still there.
   - peek at full queue.
   */
  
  @Test(timeout=1000) public void CircularQueue_element_1(){
    CircularQueue q = new CircularQueue(50);
    
    // no items to peek at!
    try {
      Integer ans = q.element();
      fail ("should have thrown exception.");
    } catch (RuntimeException e) {
      assertEquals("Queue empty",e.getMessage());
    }
    
    assertEquals("", q.toString());
  }
  
  @Test(timeout=1000) public void CircularQueue_element_2(){
    CircularQueue q = new CircularQueue(50);
    q.add(51);
    
    Integer ans = q.element();
    assertEquals((Integer)51,ans);
    assertEquals("51",q.toString());
  }
  
  @Test(timeout=1000) public void CircularQueue_element_3(){
    CircularQueue q = new CircularQueue(50);
    q.add(51);
    q.add(-234);
    q.add(456);
    q.add(7979);
    
    Integer ans = q.element();
    assertEquals((Integer)51, ans);
    
    assertEquals("51 -234 456 7979",q.toString());
  }
  
  @Test(timeout=1000) public void CircularQueue_element4(){
    CircularQueue q = new CircularQueue(4);
    q.add(51);
    q.add(-234);
    q.add(456);
    q.add(7979);
    
    Integer ans = q.element();
    assertEquals((Integer)51,ans);
    
    // try it again...
    ans = q.element();
    assertEquals((Integer)51,ans);
    
    // try it again...
    ans = q.element();
    assertEquals((Integer)51,ans);
    
    assertEquals("51 -234 456 7979",q.toString());
  }
  
  
  @Test(timeout=1000) public void CircularQueue_peek_1(){
    CircularQueue q = new CircularQueue(50);
    
    // no items to peek at! We should get null.
    Integer ans = q.peek();
    assertEquals(null,ans);
    
    assertEquals("", q.toString());
  }
  
  @Test(timeout=1000) public void CircularQueue_peek_2(){
    CircularQueue q = new CircularQueue(50);
    q.add(51);
    
    Integer ans = q.peek();
    assertEquals((Integer)51,ans);
    assertEquals("51",q.toString());
  }
  
  @Test(timeout=1000) public void CircularQueue_peek_3(){
    CircularQueue q = new CircularQueue(50);
    q.add(51);
    q.add(-234);
    q.add(456);
    q.add(7979);
    
    Integer ans = q.peek();
    assertEquals((Integer)51, ans);
    
    assertEquals("51 -234 456 7979",q.toString());
  }
  
  @Test(timeout=1000) public void CircularQueue_peek4(){
    CircularQueue q = new CircularQueue(4);
    q.add(51);
    q.add(-234);
    q.add(456);
    q.add(7979);
    
    Integer ans = q.peek();
    assertEquals((Integer)51,ans);
    
    // try it again...
    ans = q.peek();
    assertEquals((Integer)51,ans);
    
    // try it again...
    ans = q.peek();
    assertEquals((Integer)51,ans);
    
    assertEquals("51 -234 456 7979",q.toString());
  }
  
  @Test(timeout=1000) public void CircularQueue_internalsString1(){
    CircularQueue q = new CircularQueue(4);
    assertEquals("[null, null, null, null]", q.internalsString());
  }    

  @Test(timeout=1000) public void CircularQueue_internalsString2(){
    CircularQueue q = new CircularQueue(4);
    assertEquals("[null, null, null, null]", q.internalsString());
    q.add(51);
    q.add(-234);
    assertEquals("[51, -234, null, null]", q.internalsString());

    q.add(456);
    q.add(7979);
    assertEquals("[51, -234, 456, 7979]", q.internalsString());
  }  

  @Test(timeout=1000) public void CircularQueue_addRemove1(){
    CircularQueue q = new CircularQueue(4);
    assertEquals("[null, null, null, null]", q.internalsString());
    q.add(51);
    q.add(-234);
    assertEquals("[51, -234, null, null]", q.internalsString());

    assertEquals(51,(int) q.remove());
    assertEquals("[null, -234, null, null]", q.internalsString());

    assertEquals(-234,(int) q.remove());
    assertEquals("[null, null, null, null]", q.internalsString());

    assertEquals(null, q.peek());
    try{
      q.element();
      fail ("should have thrown exception.");
    } catch (RuntimeException e) {
      assertEquals("Queue empty",e.getMessage());
    }
  }    
  @Test(timeout=1000) public void CircularQueue_addRemove2(){
    CircularQueue q = new CircularQueue(4);
    assertEquals("[null, null, null, null]", q.internalsString());
    assertTrue(q.add(51));
    assertTrue(q.add(-234));
    assertEquals("[51, -234, null, null]", q.internalsString());

    assertEquals(51,(int)q.remove());
    assertEquals("[null, -234, null, null]", q.internalsString());

    assertEquals(-234, (int)q.peek());
    assertEquals(-234, (int)q.element());

    assertTrue(q.offer(456));
    assertTrue(q.offer(7979));
    assertEquals("[null, -234, 456, 7979]", q.internalsString());
  }    
  @Test(timeout=1000) public void CircularQueue_addRemove3(){
    CircularQueue q = new CircularQueue(4);
    assertEquals("[null, null, null, null]", q.internalsString());
    assertTrue(q.add(51));
    assertTrue(q.add(-234));
    assertEquals("[51, -234, null, null]", q.internalsString());

    assertEquals(51,(int)q.remove());
    assertEquals("[null, -234, null, null]", q.internalsString());

    assertTrue(q.offer(456));
    assertTrue(q.offer(7979));
    assertEquals("[null, -234, 456, 7979]", q.internalsString());

    assertEquals(-234,(int)q.remove());
    assertTrue(q.add(1));
    assertEquals("[1, null, 456, 7979]", q.internalsString());

    assertEquals(456,(int)q.remove());
    assertTrue(q.add(2));
    assertEquals("[1, 2, null, 7979]", q.internalsString());

    assertEquals(7979,(int)q.remove());
  }    
  @Test(timeout=1000) public void CircularQueue_addRemove4(){
    CircularQueue q = new CircularQueue(3);
    assertEquals("[null, null, null]", q.internalsString());
    assertTrue(q.add(1));
    assertTrue(q.add(2));
    assertEquals("[1, 2, null]", q.internalsString());

    assertEquals(1,(int)q.remove());
    assertEquals(2,(int)q.remove());
    assertEquals("[null, null, null]", q.internalsString());

    assertTrue(q.add(3));
    assertTrue(q.add(4));
    assertEquals("[4, null, 3]", q.internalsString());
    assertEquals("3 4", q.toString());

    assertEquals(3,(int)q.remove());
    assertEquals(4,(int)q.remove());
    assertEquals("[null, null, null]", q.internalsString());
    assertEquals("", q.toString());

    assertEquals(null, q.peek());
    try{
      q.element();
      fail("should have thrown exception.");
    }
    catch(RuntimeException e){
      assertEquals("Queue empty",e.getMessage());
    }

    assertTrue(q.add(5));
    assertTrue(q.add(6));
    assertEquals("[null, 5, 6]", q.internalsString());
    assertEquals("5 6", q.toString());
    assertEquals(5,(int) q.peek());
    assertEquals(5,(int) q.element());

    assertTrue(q.add(7));
    assertEquals("[7, 5, 6]", q.internalsString());
    assertEquals("5 6 7", q.toString());

    assertEquals(5,(int)q.remove());
    assertEquals(6,(int)q.remove());
    assertEquals("[7, null, null]", q.internalsString());
    assertEquals(7,(int) q.peek());
    assertEquals(7,(int) q.element());

    assertEquals(7,(int)q.remove());
    assertEquals("[null, null, null]", q.internalsString());
    assertEquals("", q.toString());

    assertEquals(null, q.peek());
    try{
      q.element();
      fail ("should have thrown exception.");
    } catch (RuntimeException e) {
      assertEquals("Queue empty",e.getMessage());
    }
  }

  @Test(timeout=1000) public void CircularQueue_addRemoveExpand1(){
    CircularQueue q = new CircularQueue(3);
    assertEquals("[null, null, null]", q.internalsString());
    assertEquals("", q.toString());

    assertTrue(q.add(1));
    assertTrue(q.add(2));
    assertEquals("[1, 2, null]", q.internalsString());
    assertEquals("1 2", q.toString());

    assertEquals(1,(int)q.remove());
    assertEquals(2,(int)q.remove());
    assertEquals("[null, null, null]", q.internalsString());
    assertEquals("", q.toString());

    assertTrue(q.add(3));
    assertTrue(q.add(4));
    assertEquals("[4, null, 3]", q.internalsString());
    assertEquals("3 4", q.toString());

    assertTrue(q.add(5));
    assertEquals("[4, 5, 3]", q.internalsString());
    assertEquals("3 4 5", q.toString());
    assertEquals(3, q.getCapacity());

    // Expand
    assertTrue(q.add(6));
    assertEquals("[3, 4, 5, 6, null, null]", q.internalsString());
    assertEquals("3 4 5 6", q.toString());
    assertEquals(6, q.getCapacity());

    assertEquals(3,(int)q.remove());
    assertEquals(4,(int)q.remove());
    assertEquals("[null, null, 5, 6, null, null]", q.internalsString());
    assertEquals("5 6", q.toString());

    assertTrue(q.offer(7));
    assertTrue(q.offer(8));
    assertTrue(q.offer(9));
    assertTrue(q.offer(10));
    assertEquals("[9, 10, 5, 6, 7, 8]", q.internalsString());
    assertEquals("5 6 7 8 9 10", q.toString());

    assertEquals(5,(int)q.remove());
    assertEquals("[9, 10, null, 6, 7, 8]", q.internalsString());
    assertEquals("6 7 8 9 10", q.toString());

    assertTrue(q.offer(11));
    assertEquals("[9, 10, 11, 6, 7, 8]", q.internalsString());
    assertEquals("6 7 8 9 10 11", q.toString());
    assertEquals(6, q.getCapacity());

    assertTrue(q.offer(12));
    assertEquals("[6, 7, 8, 9, 10, 11, 12, null, null, null, null, null]", q.internalsString());
    assertEquals("6 7 8 9 10 11 12", q.toString());
    assertEquals(12, q.getCapacity());

    assertEquals(6,(int)q.remove());
    assertEquals("[null, 7, 8, 9, 10, 11, 12, null, null, null, null, null]", q.internalsString());
    assertEquals("7 8 9 10 11 12", q.toString());

    assertTrue(q.add(13));
    assertEquals("[null, 7, 8, 9, 10, 11, 12, 13, null, null, null, null]", q.internalsString());
    assertEquals("7 8 9 10 11 12 13", q.toString());
  }

  @Test(timeout=1000) public void CircularQueue_addRemoveExpand2(){
    CircularQueue q = new CircularQueue(-5);
    assertEquals("[null]", q.internalsString());
    assertEquals("", q.toString());
    assertEquals(1, q.getCapacity());

    assertTrue(q.offer(10));
    assertEquals("[10]", q.internalsString());
    assertEquals("10", q.toString());
    assertEquals(1, q.getCapacity());

    // Expand
    assertTrue(q.offer(11));
    assertEquals("[10, 11]", q.internalsString());
    assertEquals("10 11", q.toString());
    assertEquals(2, q.getSize());
    assertEquals(2, q.getCapacity());

    // Expand
    assertTrue(q.offer(12));
    assertEquals("[10, 11, 12, null]", q.internalsString());
    assertEquals("10 11 12", q.toString());
    assertEquals(3, q.getSize());
    assertEquals(4, q.getCapacity());

    // Expand
    assertTrue(q.offer(13));
    assertTrue(q.offer(14));
    assertEquals("[10, 11, 12, 13, 14, null, null, null]", q.internalsString());
    assertEquals("10 11 12 13 14", q.toString());
    assertEquals(5, q.getSize());
    assertEquals(8, q.getCapacity());

    assertEquals(10, (int)q.poll());
    assertEquals(11, (int)q.poll());
    assertEquals(12, (int)q.peek());
    assertEquals(12, (int)q.element());
    assertEquals(12, (int)q.poll());
    assertEquals(13, (int)q.poll());

    assertEquals("[null, null, null, null, 14, null, null, null]", q.internalsString());
    assertEquals("14", q.toString());
    assertEquals(1, q.getSize());
    assertEquals(8, q.getCapacity());

    assertTrue(q.offer(15));
    assertTrue(q.offer(16));
    assertTrue(q.offer(17));
    assertTrue(q.offer(18));
    assertTrue(q.offer(19));
    assertTrue(q.offer(20));
    assertEquals("[18, 19, 20, null, 14, 15, 16, 17]", q.internalsString());
    assertEquals("14 15 16 17 18 19 20", q.toString());
    assertEquals(7, q.getSize());
    assertEquals(8, q.getCapacity());
    assertEquals(14, (int)q.peek());
    assertEquals(14, (int)q.element());

    // Expand
    assertTrue(q.offer(21));
    assertTrue(q.offer(22));
    assertEquals("[14, 15, 16, 17, 18, 19, 20, 21, 22, null, null, null, null, null, null, null]", q.internalsString());
    assertEquals("14 15 16 17 18 19 20 21 22", q.toString());
    assertEquals(9, q.getSize());
    assertEquals(16, q.getCapacity());
    assertEquals(14, (int)q.peek());
    assertEquals(14, (int)q.element());
  }
}