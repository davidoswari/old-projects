import java.util.Arrays;
import java.util.Scanner;
import java.io.File;
import java.io.FileNotFoundException;
//David Oswari G01013002
//Application class
public class Application
{
   static Disk disk = new Disk(2000,512);
   static DirectFile directFile = new DirectFile(disk,60,27,1024,600);
   static Scanner sc = new Scanner(System.in);
   
   public static void main(String[] args) throws FileNotFoundException
   {
      boolean running = true;
      scanFile();
      while(running)
      {
         printMenu();
         String input = sc.nextLine();
      
         switch(input)
         {
            case "i":
               insertRecord();
               break;
               
            case "f":
               findRecord();
               break;
            
            case "q":
               running = false;
               break;
               
            default:
               System.out.println("invalid command\n");
                          
         }
      }
   }
   //prints the menu
   public static void printMenu()
   {
      System.out.println("Insert new record:  i");
      System.out.println("Find record: f");
      System.out.println("Quit: q");
      System.out.print("-> ");
   }
   //gets information from user, creates a record, and tries to insert it
   public static void insertRecord()
   {
      System.out.print("Mountain name: ");
      String key = sc.nextLine();
      System.out.print("Country: ");
      String country = sc.nextLine();
      System.out.print("Altitude: ");
      String alt = sc.nextLine();
      System.out.println("");//for spacing
      
      int keyLength= key.length();
      int countryLength = country.length();
      int altLength = alt.length();
      
      //truncate
      if(keyLength>27)
         keyLength=27;
      if(countryLength>27)
         countryLength=27;
      if(altLength>6)
         altLength=6;
      
      char[] record = new char[60];
      Arrays.fill(record,'\000');
      
      //copy character by character
      int i,pos;
      pos=0;  
      for(i=0;i<keyLength;i++)
      {
         record[pos++] = key.charAt(i);
      }  
      pos = 27;
      for(i=0;i<countryLength;i++)
      {
         record[pos++] = country.charAt(i);
      }
      pos = 54;  
      for(i=0;i<altLength;i++)
      {
         record[pos++] = alt.charAt(i);
      }
      
      directFile.insertRecord(record);
   }
   //gets key from user and tries to find record
   public static void findRecord()
   {
      System.out.print("Mountain name: ");
      String key = sc.nextLine();
      //truncate
      int keyLength=key.length();
      if(keyLength>27)
         keyLength=27;
      char[] record =new char[60];
      Arrays.fill(record, '\000');
    
      for(int i=0;i<keyLength;i++)
         record[i] = key.charAt(i);
         
      if(directFile.findRecord(record)==false)
      System.out.println("record not found\n");
   }
   
   //read file and insert records
   public static void scanFile() throws FileNotFoundException
   {
      try{
         Scanner fs = new Scanner(new File("mountains.txt"));
         while(fs.hasNext())
         {
            String temp = fs.nextLine();
            char[] record = new char[60];
            Arrays.fill(record,'\000');
            int pos = 0;
            for(int i=0;i<27;i++)
            {
               if(temp.charAt(pos)=='#')
                  break;
               record[i] = temp.charAt(pos++);
            }
            pos++;
            for(int j=27;j<54;j++)
            {
               if(temp.charAt(pos)=='#')
                  break;
               record[j] = temp.charAt(pos++);
            
            }
            pos++;
            for(int k=54;k<60;k++)
            {
               if(pos>=temp.length() || temp.charAt(pos)=='#')
                  break;
               record[k] = temp.charAt(pos++);
            
            }
            directFile.insertRecord(record);
         
         }
      }
      catch(FileNotFoundException e)
      {
         System.out.println("could not read file");
      }
      
   }
}