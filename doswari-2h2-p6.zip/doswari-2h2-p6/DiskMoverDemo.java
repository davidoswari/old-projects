/**
*@author: David Oswari
*@version: 1.0
*
 * Driver class for the DiskMover class.
 */ 
public class DiskMoverDemo
{
  /**
   * Method to print instructions to move three 
   * disks from peg 1 to peg 3. 
   */ 
   public static void main(String[] args)
   {
      int n = 3;
      DiskMover mover = new DiskMover(n, 1, 3);
      while (mover.hasMoreMoves())
      {
         System.out.println(mover.nextMove());
      }
   }
}
