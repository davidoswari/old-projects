import java.util.Scanner;

//David Oswari
//This class runs the Grid
public class GridDriver
{
   public static Scanner sc = new Scanner(System.in);
   public static Grid grid = new Grid();
   
   public static void main(String[] args)
   {
      boolean running = true;
      //loop until "q"
      while(running)
      {
         displayMenu();
         System.out.print("-> ");
         String input = sc.nextLine();
         switch(input)
         {
            case "dis":
               display();
               break;
               
            case "as":
               assignCell();
               break;
            
            case "f":
               fill();
               break;
         
            case "n":
               number();
               break;
               
            case "a":
               addCells();
               break;
            
            case "s":
               subtractCells();
               break;
         
            case "m":
               multiplyCells();
               break;
           
            case "d":
               divideCells();
               break;
               
            case"ar":
               addRows();
               break;
            
            case"sr":
               subtractRows();
               break;
         
            case"mr":
               multiplyRows();
               break;
         
            case"dr":
               divideRows();
               break;
            
            case"ac":
               addColumns();
               break;
            
            case"sc":
               subtractColumns();
               break;
         
            case"mc":
               multiplyColumns();
               break;
         
            case"dc":
               divideColumns();
               break;
               
            case"ir":
               insertRow();
               break;
               
            case"ic":
               insertColumn();
               break;
               
            case"delc":
               deleteColumn();
               break;
               
            case"delr":
               deleteRow();
               break;
         
            case "q":
               running = false;
               break;
         
            default:
               System.out.println("invalid command");
         }
      }  
   }
   //this method prints the menu
   public static void displayMenu()
   {
      System.out.println("");
      System.out.println("Operations");
      System.out.printf("%20s %5s %20s %5s\n", "display", "dis", "assign cell", "as");
      System.out.printf("%20s %5s %20s %5s\n", "fill", "f", "number", "n");
      System.out.printf("%20s %5s %20s %5s\n", "add cells", "a", "subtract cells", "s");
      System.out.printf("%20s %5s %20s %5s\n", "multiply cells", "m", "divide cells", "d");
      System.out.printf("%20s %5s %20s %5s\n", "add rows", "ar", "subtract rows", "sr");
      System.out.printf("%20s %5s %20s %5s\n", "multiply rows", "mr", "divide rows", "dr");         
      System.out.printf("%20s %5s %20s %5s\n", "add columns", "ac", "subtract columns", "sc");          
      System.out.printf("%20s %5s %20s %5s\n", "multiply columns", "mc", "divide columns", "dc");
      System.out.printf("%20s %5s %20s %5s\n", "insert row", "ir", "insert column", "ic");
      System.out.printf("%20s %5s %20s %5s\n", "delete row", "delr", "delete column", "delc");
      System.out.printf("%20s %5s\n", "quit", "q");
   }
   //display the grid
   public static void display()
   {
      grid.printGrid();
   }
   
   //this method fills grid between two cells with values given by user
   public static void fill()
   {
   //get user inputs
      System.out.print("from row: ");
      int row = getValue();
      System.out.print("from column: ");
      int col = getValue();
      System.out.print("to row:");
      int row2 = getValue();
      System.out.print("to column:");
      int col2 = getValue();
      System.out.print("with value: ");
      String value = sc.nextLine();
    //assign value
      grid.fill(row,col,row2,col2,value);
   }
   
   //this method numbers grid between two cells given by the user
   public static void number()
   {
      System.out.print("from row: ");
      int row = getValue();
      System.out.print("from column: ");
      int col = getValue();
      System.out.print("to row: ");
      int row2 = getValue();
      System.out.print("to column: ");
      int col2 = getValue();
      //number the cells
      grid.numberCells(row,col,row2,col2);
   } 
   
   //this method is used to change the value of one cell
   public static void assignCell()
   {
   //get user inputs
      System.out.print("which row: ");
      int row = getValue();
      System.out.print("which column: ");
      int col = getValue();
      System.out.print("with value: ");
      String value = sc.nextLine();
    //assign value
      grid.assignCell(row,col,value);
   }
   
   //this method is used to subtract two cells, and put difference in target cell
   public static void subtractCells()
   {
   //get user inputs
      System.out.print("first node row: ");
      int row1 = getValue();
      System.out.print("first node column: ");
      int col1 = getValue();
      System.out.print("second node row: ");
      int row2 = getValue();
      System.out.print("second node column:");
      int col2 = getValue();
      System.out.print("destination node row:");
      int drow = getValue();
      System.out.print("destination node column:");
      int dcol = getValue();
      //calculate difference
      Value v = grid.subtractCells(row1,col1,row2,col2);
      
      //if Value is not invalid, then change the cell
      if(v.tag!=2)
      {
         grid.assignCell(drow,dcol,v);
      }
   }
   
   //this method is used to multiply two cells and store result in target cell
   public static void multiplyCells()
   {
   //get user inputs
      System.out.print("first node row: ");
      int row1 = getValue();
      System.out.print("first node column: ");
      int col1 = getValue();
      System.out.print("second node row: ");
      int row2 = getValue();
      System.out.print("second node column:");
      int col2 = getValue();
      System.out.print("destination node row:");
      int drow = getValue();
      System.out.print("destination node column:");
      int dcol = getValue();
      //calculate product
      Value v = grid.multiplyCells(row1,col1,row2,col2);
      
      //if Value is not invalid, then change the cell
      if(v.tag!=2)
      {
         grid.assignCell(drow,dcol,v);
      }
   }
   
//this method is used to divide two cells and store result in target cell
   public static void divideCells()
   {
   //get user inputs
      System.out.print("first node row: ");
      int row1 = getValue();
      System.out.print("first node column: ");
      int col1 = getValue();
      System.out.print("second node row: ");
      int row2 = getValue();
      System.out.print("second node column:");
      int col2 = getValue();
      System.out.print("destination node row:");
      int drow = getValue();
      System.out.print("destination node column:");
      int dcol = getValue();
      //calculate quotient
      Value v = grid.divideCells(row1,col1,row2,col2);
      
      //if Value is not invalid, then change the cell
      if(v.tag!=2)
      {
         grid.assignCell(drow,dcol,v);
      }
   }
   
 //this method is used to add two cells and store result in target cell
   public static void addCells()
   {
   //get user inputs
      System.out.print("first node row: ");
      int row1 = getValue();
      System.out.print("first node column: ");
      int col1 = getValue();
      System.out.print("second node row: ");
      int row2 = getValue();
      System.out.print("second node column: ");
      int col2 = getValue();
      System.out.print("destination node row: ");
      int drow = getValue();
      System.out.print("destination node column: ");
      int dcol = getValue();
      //calculate sum
      Value v = grid.addCells(row1,col1,row2,col2);   
      //if Value is not invalid, then change the cell
      if(v.tag!=2)
      {
         grid.assignCell(drow,dcol,v);
      }
   }
   
  //this method is used to add two rows and store result in target row
   public static void addRows()
   {  
      //user input
      System.out.print("first row: ");
      int row1 = getValue();
      System.out.print("second row: ");
      int row2 = getValue();
      System.out.print("target row: ");
      int targetRow = getValue();
      //add rows
      grid.addRows(row1,row2,targetRow);
      
   }
   
  //this method is used to subtract two rows and store result in target row
   public static void subtractRows()
   {
      //user input
      System.out.print("first row: ");
      int row1 = getValue();
      System.out.print("second row: ");
      int row2 = getValue();
      System.out.print("target row: ");
      int targetRow = getValue();
      //subtract rows
      grid.subtractRows(row1,row2,targetRow);   
   }
   
  //this method is used to divide two rows and store result in target row
   public static void divideRows()
   {
      //user inputs
      System.out.print("first row: ");
      int row1 = getValue();
      System.out.print("second row: ");
      int row2 = getValue();
      System.out.print("target row: ");
      int targetRow = getValue();
      //divide rows
      grid.divideRows(row1,row2,targetRow);
   }
   
  //this method is used to divide two rows and store result in target row 
   public static void multiplyRows()
   {
      //user inputs
      System.out.print("first row: ");
      int row1 = getValue();
      System.out.print("second row: ");
      int row2 = getValue();
      System.out.print("target row: ");
      int targetRow = getValue();
      //multiply rows
      grid.multiplyRows(row1,row2,targetRow);  
   }
   
   public static void addColumns()
   {
      //user inputs
      System.out.print("first column: ");
      int col1 = getValue();
      System.out.print("second column: ");
      int col2 = getValue();
      System.out.print("target column: ");
      int targetCol = getValue();
      //add columns
      grid.addColumns(col1,col2,targetCol);  
   }
   
   //this method is used to divide two columns and store result in target columns
   public static void divideColumns()
   {
      //user inputs
      System.out.print("first column: ");
      int col1 = getValue();
      System.out.print("second column: ");
      int col2 = getValue();
      System.out.print("target column: ");
      int targetCol = getValue();
      //divide columns
      grid.divideColumns(col1,col2,targetCol);  
   }
   
   //this method is used to subtract two columns and store result in target column
   public static void subtractColumns()
   {
      //user inputs
      System.out.print("first column: ");
      int col1 = getValue();
      System.out.print("second column: ");
      int col2 = getValue();
      System.out.print("target column: ");
      int targetCol = getValue();
      //subtract columns
      grid.subtractColumns(col1,col2,targetCol);  
   }
   
   //this method is used to multiply two columns and store result in target column
   public static void multiplyColumns()
   {
      //user input
      System.out.print("first column: ");
      int col1 = getValue();
      System.out.print("second column: ");
      int col2 = getValue();
      System.out.print("target column: ");
      int targetCol = getValue();
      //multiply columns
      grid.multiplyColumns(col1,col2,targetCol);  
   }

//this method is used to insert a row after a given row
   public static void insertRow()
   {
      //user input
      System.out.print("insert after row: ");
      int row = getValue();
      //insert row
      if(row==-1)
         grid.insertFirstRow();
      else
         grid.insertRow(row);
   }
 
 //this method is used to delete a row
   public static void deleteRow()
   {
      System.out.print("delete row: ");
      int row = getValue();
      //delete row
      grid.deleteRow(row);
   }
 //this method is used to insert a column after a given column  
   public static void insertColumn()
   {
      //user input
      System.out.print("insert after column: ");
      int col = getValue();
      //insert column
      if(col==-1)
         grid.insertFirstColumn();
      else
         grid.insertColumn(col);
   }
   
   //this method is used to delete a column
   public static void deleteColumn()
   {
      //user input
      System.out.print("delete column: ");
      int col = getValue();
      //delete column
      grid.deleteColumn(col);
   }

   //get an int from the user
   public static int getValue()
   {
      int value = sc.nextInt();
      String clear = sc.nextLine();//enter character is stored in scanner after sc.nextInt()
      return value;
   }

}