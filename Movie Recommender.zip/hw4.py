#attempt 1 -> 0.88 on miner: returned average of all user ratings for a given movie
#attempt 2 -> 0.91 on miner: removed min and max rating, and replaced with average rating
#attempt 3 ->

import numpy as np
print("load in training and testing set data")
train = np.loadtxt("train.dat", skiprows= 1)
test = np.loadtxt("test.dat",skiprows = 1)

print ("hashing data")
#hash the training data and count how many users watched each movie, and keep sum of ratings
averages = {}
for i in train:
    userid = i[0]
    movieid = i[1]
    rating = i[2]
    if movieid in averages:
        value = averages.get(movieid)
        value[0] = value[0] + 1
        value[1] = value[1] + rating
    else:
        averages[movieid] = [1,rating]

print("predicting ratings for test set")
output = open("output.txt", "w+")
#compute the ratings for each movie
#output to file
for i in range(0,len(test)):
    temp = test[i]
    movieid = temp[1]
    if movieid in averages:
        value = averages.get(movieid)
        retval = (value[1]/value[0])
        output.write(str(retval))
        output.write("\n")
    else:
        retval = 3 # cold start
        output.write(str(retval))
        output.write("\n")
output.close()

print("done")

        
        
               
        
            
        
        
    


        
    



