public class CircularQueue{
   private Integer[] queue;
   private int size=0;
   private int front=0;
   private int rear = 0;
   
   public CircularQueue(int maxCapacity)
   {
      if(maxCapacity<=0)
         maxCapacity=1;
   
      Integer[] queue = new Integer[maxCapacity];
      for(int i=0;i<queue.length;i++)
         queue[i]=null; //sets everything in queue as null
      this.queue = queue;
   }

   public int getSize()
   {
      return size;
   }
  
   public int getCapacity()
   {
      return queue.length;
   }
   
   public boolean isFull()
   {
      return size==queue.length;
   }
   
   public boolean isEmpty()
   {
      return size==0;
   }

   public boolean add(Integer e)
   {
      if(e==null)
         throw new RuntimeException("Cannot add null");
      
   
      if(isFull())
         doubleQueue();// method that doubles the length of queue and orders it.
   
    
      if (rear == queue.length) 
      {
         rear = 0;
      }
         
      queue[rear]= e;
      rear++;
      size++;
      
      
      return true;
   }
   
        
   
   public void doubleQueue()
   {
   
      Integer[] biggerQueue = new Integer[queue.length*2];
      int spot =0;
      //front to end of queue
      for(int i=front;i<queue.length;i++)
      {
         biggerQueue[spot]=queue[i];
         spot++;
      }
      //0 to front of queue
      if(front!=0)
         for(int i=0;i<front;i++)
         {
            biggerQueue[spot]=queue[i];
            spot++;
         }
      front=0;
      rear=spot;
      queue= biggerQueue;
   }

   public boolean offer(Integer e)
   {
   //exactly the same as add
      return add(e);
   }

   public Integer remove()
   {
      if(isEmpty())
         throw new RuntimeException("Queue empty");
   
      Integer removed =queue[front];
      queue[front]=null;
      front++;
      size--;
      //when front equals length, set equal to 0
      if (front == queue.length )
      {
         front=0;
      }
      
      return removed;
   }
   
   public Integer poll()
   {
   //same as remove, except returns null
      if(isEmpty())
         return null;
   
      Integer removed =queue[front];
      queue[front]=null;
      front++;
      size--;
      return removed;
   
   }

   public Integer element()
   {
      if(isEmpty())
         throw new RuntimeException("Queue empty");
      return queue[front];
   }

   public Integer peek()
   {
   //same as element except returns null
      if(isEmpty())
         return null;
   
      return queue[front];
   }

       
   public String toString()
   {
      String result = "";
      //front to end
      for(int i=front;i<queue.length;i++)
      {
         if(queue[i]!=null)
         {
            if(i==front)
            {
               result = queue[front]+ "";
            }
            else
               result = result + " " + queue[i];
         }
              
      }
      //0 to front
      if(front!=0)
         for(int i=0;i<front;i++)
         {
            if(queue[i]!=null)
            {
               result = result + " " + queue[i];
            }
         }
      return result;
   }      
   public String internalsString()
   {
      String result = "";
      for(int i=0;i<queue.length;i++)
      {
       
         if(i==0)
         {
            result = queue[0]+ "";
         }
         else
            result = result + ", " + queue[i];
      
      }
      
      return "[" + result + "]";
   }
   
}