public class Hourly extends StaffMember
{
  //payRate represents per hour pay rate
   private double hours;
   private double overtimeHours;
 
   public Hourly(int ID, String firstName, String lastName, double payRate)
   {
      super(ID,firstName,lastName,payRate);
   }
   public double getPaid()
   {
      if(hours==80)//checks if hours are 80
      {
         double payment = (hours + overtimeHours)*this.getPayRate();//hourly pay * hours + hourly pay * overtime hours
         hours=0;//set hours and overtime hours to zero
         overtimeHours=0;
         return payment;
      }
      else
         return 0;
   }
   public double getHours()
   {
      return hours;
   }
   
   public void addHours(double hours)
   {
      while(hours>0)
      {
         if(this.hours==80)//when hours reaches 80, count overtime hours
         {
            overtimeHours++;
            hours--;
         }
         else
         {
            this.hours++;
            hours--;
         }
         
      }
   }
   public String employeeType()
   {
      return "Hourly";
   }

}