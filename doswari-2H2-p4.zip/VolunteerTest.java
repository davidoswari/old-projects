import static org.junit.Assert.*;
import org.junit.Test;
import org.junit.*;

/**
 * @author: David Oswari
 * @version: 1.0
 * 
 * this code tests all methods in Volunteer class
 **/ 

public class VolunteerTest
{
private Volunteer david,alex;

/**
 *this sets up 2 volunteers to be used in test cases 
 **/
@Before
public void setUp()
{
david = new Volunteer(1,"David","Oswari",0);
alex = new Volunteer(-1,"Alex" , "Oswari", 5000);
}

/**
 * testing the getFirstName method
 **/
@Test
public void getFirstNameTest()
{
  assertTrue(alex.getFirstName().equals("Alex"));
  assertTrue(david.getFirstName().equals("David"));
}

/**
 * testing the getLastName method
 **/
@Test
public void getLastNameTest()
{
  assertTrue(alex.getLastName().equals("Oswari"));
  assertTrue(david.getLastName().equals("Oswari"));
}

/**
 * testing the getID method
 **/
@Test
public void getIDTest()
{
  assertTrue(alex.getID()==-1);
  assertTrue(david.getID()==1);
}

/**
 * testing the getPayRate and setPayRate methods
 **/
@Test
public void getSetPayRate()
{
assertTrue(david.getPayRate()==0);
assertTrue(alex.getPayRate()==5000);
  
david.setPayRate(1000);
alex.setPayRate(-1000);
assertTrue(david.getPayRate()==1000);
assertTrue(alex.getPayRate()==-1000);
}

/**
 * testing getPaid method
 **/
@Test
public void getPaidTest()
{  
assertTrue(david.getPaid()==0);
assertTrue(alex.getPaid()==0);
}

/**
 * checks if employee type is correct
 **/
@Test
public void employeeTypeTest()
{
assertTrue(david.employeeType().equals("Volunteer"));
assertTrue(alex.employeeType().equals("Volunteer"));
}
}