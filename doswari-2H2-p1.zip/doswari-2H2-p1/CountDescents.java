public class CountDescents
{

   public static int countDescents(int[] xs)
   {
      if(xs.length==0)// if empty
         return 0;
      int count=1;
      for(int i=0;i<xs.length-1;i++)
      {
         if(xs[i]<xs[i+1])  // if next number is greater, add to count
            count++;
      }
            
      return count;
   }
}