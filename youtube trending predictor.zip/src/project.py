#youtube trending predictor
#test predictions are formatted like: trending date, title, date and time published, tags, views, likes, dislikes
#tags don't do anything in this model
import csv
from sklearn.neighbors import NearestNeighbors
from datetime import datetime

#get the dataset
dataset = "USvideos.csv"
with open(dataset, newline='') as csvfile:
    data = list(csv.reader(csvfile))
    
#get the dataset
testset = "test"
with open(testset, newline='') as csvfile:
    testdata = list(csv.reader(csvfile))
    
#actual
with open("actual.txt",newline='')as csvfile:
    actual = list(csv.reader(csvfile))
print(actual)

#find k nearest neighbors based on view to like/dislike ratio
rows = len(data)
cols = 3    
arr = [0]*rows
for i in range(rows):
    arr[i] = [0] * cols

rows = len(testdata)
cols = 3    
arr2 = [0]*rows
for i in range(rows):
    arr2[i] = [0] * cols

r = -1 
for i in data:
    if r>=0:
        #ratios
        arr[r][0] = (float(i[5])+1)/(float(i[6])+1) #ratio between likes and dislikes
        arr[r][1] = (float(i[4])+1)/(float(i[5])+1) # ratio between views and likes
        date_format = "%y.%d.%m"
        date_format2 = "%m/%d/%Y %H:%M"
        a = datetime.strptime(i[0], date_format)
        b = datetime.strptime(i[2], date_format2)
        delta = abs((a - b).total_seconds())
        arr[r][2] = delta #time between creation and trending
    r+=1


r = 0
for i in testdata:
        #ratios
    print(float(i[5]))
    print(float(i[6]))
    arr2[r][0] = (float(i[5])+1)/(float(i[6])+1) #ratio between likes and dislikes
    arr2[r][1] = (float(i[4])+1)/(float(i[5])+1) # ratio between views and likes
    date_format = "%y.%d.%m"
    date_format2 = "%m/%d/%Y %H:%M"
    a = datetime.strptime(i[0], date_format)
    b = datetime.strptime(i[2], date_format2)
    delta = abs((b-a).total_seconds())
    arr2[r][2] = delta #time between creation and trending
    r+=1


X = arr
Y = arr2
k = 5

nbrs = NearestNeighbors(n_neighbors = k, algorithm = 'ball_tree').fit(X)
distances, indices = nbrs.kneighbors(Y)
#got the nearest neighbors in indices 
r = 0
predictions = []
correct=0
for i in indices:
    date_format = "%y.%d.%m"
    date_format2 = "%m/%d/%Y %H:%M"
    a = datetime.strptime(testdata[r][0], date_format)
    b = datetime.strptime(testdata[r][2], date_format2)
    delta = abs((a - b).total_seconds())
    actualdelta = delta #time between creation and trending
    averageviews= 0
    averagedelta =0
    
    for x in i:
        #print(data[x][1])
        averageviews += int(data[x][4])
        date_format = "%y.%d.%m"
        date_format2 = "%m/%d/%Y %H:%M"
        a = datetime.strptime(data[x][0], date_format)
        b = datetime.strptime(data[x][2], date_format2)
        delta = abs((a - b).total_seconds())
        averagedelta += delta #time between creation and trending
        
    #calculating the expected number of views    
    averageviews = averageviews/k
    averagedelta = float(averagedelta)/k
    idealratio = averageviews/averagedelta  
    expectedviews = idealratio * actualdelta
    expectedviews = int(abs(expectedviews)/3)
    print(testdata[r][1])
    
    
    if int(testdata[r][4])>expectedviews:
        print("WILL BE TRENDING\n")
        predictions.append("trending")
    else:
        print("WILL NOT BE TRENDING\n")
        predictions.append("not trending")
    r+=1    
    
#check accuracy
for i in range(0,len(predictions)):
    if predictions[i] == actual[i][0]:
        correct+=1
print("Accuracy",correct,"/",len(predictions))
    
        
        
        




