/**
*The dice class stores two Die.
* @author: David Oswari
* @version: 1.0
**/
public class Dice
{
   private Die one,two;
   
   public Dice()
   {
      one = new Die();
      two = new Die();
   }
/**
*this method rolls both dice.
**/
   public void roll()
   {
      one.roll();
      two.roll();
   } 
   /**
   * @return value
   *returns the value of the first die
   **/
   public int getValue1()
   {
      return one.getValue();
   }
   /**
   * @return value
   *returns the value of the second die
   **/
   public int getValue2()
   {
      return two.getValue();
   }
   /**
   * @return sum
   *returns the sum of the values of the dice
   **/
   public int getSum()
   {
      int sum = getValue1() + getValue2();
      return sum;
   }
   /**
   * @return sum
   *returns a String that represents the sum of the values of the dice
   **/
   public String printSum()
   {
      String sum =  getValue1() + " + " + getValue2() + " = " + getSum();
      return sum;
   }
   /**
   *@return hasOne
   *checks if either of the dice have a value of one.
   *returns true if there is, false if there is not.
   **/
   public boolean hasOne()
   {
      boolean hasOne= false;
      if(getValue1() ==1 || getValue2() ==1)
         hasOne=true;
      
      return hasOne;
   }
}