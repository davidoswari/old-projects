import random
import math
from scipy.spatial import distance
import numpy as np
#get the test data
test_file = open("image_data.txt", "r")
#sepal_length, sepal_width, petal_length, petal_width
data = test_file.readlines()
test_file.close()

print("creating array")
rows = len(data) 
cols = 785 #extra col to store cluster number
arr = [0]*rows
for i in range(rows):
    arr[i] = [0] * cols

for x in range (len(data)):
    line_split = data[x].split(",")
    for i in range(len(line_split)):
        arr[x][i] = float(line_split[i])
    arr[x][784] = 0
        
print("array created properly, now picking random centroids")
k = 10
centroids = []
#choose k initial centroids
for i in range(k):
    centroids.append(arr[random.randint(0,len(arr)-1)])
iterations = 30
print("centroids chosen, assigning to clusters,", iterations, " iterations, k = ", k)

for y in range(iterations):
    temp = [0] * 785
    clusters = [temp] *k
    sse = 0
    num_in_clusters = [0]*k
    for x in arr:
        d = 100000
        index=0
        n=0
        for c in centroids:
            x[784]=0
            c[784]=0
             # distances to every centroid
            n+=1
            d1 = distance.cosine(np.array(x),np.array(c))
            if d1<=d:
                #print("smaller distance found to centroid", n-1)
                index = n-1
                d = d1
        sse += d**2
        x[784] = index + 1
        num_in_clusters[index] = num_in_clusters[index] + 1
        #add to centroid
        for a in range(784):
            clusters[index][a] = clusters[index][a] + x[a]

    #calculate new centroids
    z =0
    print(num_in_clusters)
    for a in clusters:
        for b in range(784):
            if num_in_clusters[z]>0:
                centroids[z][b] = a[b] / num_in_clusters[z]
        z+=1
    print("round", y, " complete")
    print("SSE = ", sse)  
      
print("printing to file")
output = open("image_output.txt", "w+")
for i in arr:
    output.write(str(i[784]))
    output.write("\n")
output.close()