import random
import math
from scipy.spatial import distance
import numpy as np
#get the test data
test_file = open("image_data.txt", "r")
#sepal_length, sepal_width, petal_length, petal_width
data = test_file.readlines()
test_file.close()

print("creating array")
rows = len(data) 
cols = 785 #extra col to store cluster number
arr = [0]*rows
for i in range(rows):
    arr[i] = [0] * cols

for x in range (len(data)):
    line_split = data[x].split(",")
    for i in range(len(line_split)):
        arr[x][i] = float(line_split[i])
    arr[x][784] = 0
        
print("array created properly, now picking random centroids")
k = 10
centroids = []
clusters = [[]] *k
#choose k initial centroids
for i in range(k):
    centroids.append(arr[random.randint(0,len(arr)-1)])
iterations = 50
print("centroids chosen, assigning to clusters,", iterations, " iterations, k = ", k)
sse = 0
for y in range(iterations):
    sse = 0
    for x in arr:
        distances = []
        for c in centroids:
            x[784]=0
            c[784]=0
             # distances to every centroid
            distances.append(distance.cosine(np.array(x),np.array(c)))
        d = min(distances)
        temp = distances.index(d)
        sse += d**2
        x[784] = temp + 1
        clusters[temp].append(x)

    #calculate new centroids
    index = 0
    for c in clusters:
        temp = [0] * 785
        for x in c:
            for i in range(0,784):
                temp[i]+= x[i]
        for i in range(0,784):
                temp[i] = temp[i]/len(c)
        centroids[index] = temp
    print("round", y, " complete")
    
print("SSE = ", sse)    
print("printing to file")
output = open("image_output.txt", "w+")
for i in arr:
    output.write(str(i[784]))
    output.write("\n")
output.close()