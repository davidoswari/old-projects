import static org.junit.Assert.*;
import org.junit.Test;
import org.junit.*;
/**
 * This class tests a Die class's object states
 * @author: David Oswari
 * @version: 1.0 
 **/
public class DieTest
{
 private Die die;

 @Before 
 public void setUp()
 {
   die = new Die();
 }
 
 @Test
 public void dieTest()
 {
   assertTrue(die.getValue()==1);
 }
 
}
