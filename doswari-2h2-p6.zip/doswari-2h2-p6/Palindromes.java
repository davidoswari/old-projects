/**
 *@author: David Oswari
 *@version: 1.0
 *
 * Program to check if a given string is a Palindrome or not.
 */ 
public class Palindromes
{
  /**
   * Tester method that checks and prints if the given strings are Palindromes.
   */ 
   public static void main(String[] args)
   {
      String sentence1 = "Madam, I'm Adam";      
      System.out.println(sentence1);
      System.out.println("Palindrome: " + isPalindrome(sentence1)); //Output:- Palindrome: true
      String sentence2 = "Sir, I'm Eve";      
      System.out.println(sentence2);
      System.out.println("Palindrome: " + isPalindrome(sentence2)); //Output:- Palindrome: false
      String sentence3 = "A man, a plan, a canal, Panama";      
      System.out.println(sentence3);
      System.out.println("Palindrome: " + isPalindrome(sentence3)); //Output:- Palindrome: true     
   }

   /**
    * Tests whether a text is a palindrome.
    * @param text a string that is being checked
    * @return true if text is a palindrome, false otherwise
    */
   public static boolean isPalindrome(String text)
   {
      text = text.toLowerCase();
   
      if(text.length()<=1)
         return true;
         
   //if front character is not a letter, check letter next to it.
      if(text.charAt(0)<'a' || text.charAt(0)>'z')
         return isPalindrome(text.substring(1));
   //if back character is not a letter, check letter next to it.
      if(text.charAt(text.length()-1)<'a' || text.charAt(text.length()-1)>'z')
         return isPalindrome(text.substring(0,text.length()-2));
   //if front and back are not same letter, then text is not a palindrome      
      if(text.charAt(0) != text.charAt(text.length()-1))
         return false;
      
      else
         return isPalindrome(text.substring(1,text.length()-1));
   }  
}
