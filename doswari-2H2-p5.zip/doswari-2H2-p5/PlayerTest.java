import static org.junit.Assert.*;
import org.junit.Test;
import org.junit.*;
/**
 * This class tests the Player class's object states.
 * @author: David Oswari
 * @version: 1.0
 **/
public class PlayerTest
{
 private Player player;

 @Before 
 public void setUp()
 {
   player= new Player("David");
 }
 
 @Test
 public void getNameTest()
 {
   assertTrue(player.getName().equals("David"));
 }
 
 @Test
 public void getBankTest()
 {
  assertTrue(player.getBank()==0); 
 }
  
  @Test
  public void getPointsTest()
  {
   assertTrue(player.getPoints()==0); 
  }
}
