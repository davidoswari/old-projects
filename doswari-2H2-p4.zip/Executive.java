public class Executive extends Salaried
{
  /**
   * @author: David Oswari
   * @version: 2.0
   * 
   * payRate represents annual salary
   * this class allows negative numbers for ID and payRate
   * 
   * New Changes:
   * added additional bonus double
   * added setAdditionalBonus method
   * added getAdditionalBonus method
   * changed getPaid method to account for extra bonuses.
   **/
  
   private double additionalBonus;
   /**
   * @param ID
   * ID number of Executive
   * 
   * @param firstName
   * first name of Executive
   * 
   * @param lastName
   * last name of Executive
   * 
   * @param payRate
   * annual salary of Executive
   **/
   public Executive(int ID, String firstName, String lastName, double payRate)
   {
      super(ID,firstName,lastName,payRate);
   }
     /**
    *@return total 
    * total = monthly bonus + monthly pay + optional bonus
    **/
   public double getPaid()
   {
      double total =  getBonus() + this.getPayRate()/12 + this.additionalBonus;
      this.additionalBonus=0;
      return total;
   }
   /**
    * @return monthly bonus
    **/ 
   public double getBonus()
   {
      return this.getPayRate()/12*.01;
   }
    /**
    * @param ab
    * additional bonus of StaffMember
    **/ 
   public void setAdditionalBonus(double ab)
   {
      this.additionalBonus = ab;
   }
   /**
    *@return additional bonus
    *
    **/
   public double getAdditionalBonus()
   {
      return additionalBonus;
   }
     /**
    * @return "Executive"
    **/ 
   public String employeeType()
   {
      return "Executive";
   }


}