public class QuickMedian
{  
   public static int partition(int a[], int left, int right, int pivotIndex)
   {
      int pivotValue = a[pivotIndex];
      swap(a,pivotIndex,right);
      int boundaryIndex=left;
   
      for(int i=left;i<right;i++)
      {
         if(a[i]< pivotValue)
         {
            swap(a,boundaryIndex,i);
            boundaryIndex++;
         }
         
      }
      swap(a,right,boundaryIndex); // puts pivot value into correct spot;
      return boundaryIndex;
   } 
   public static void swap(int[] a, int one, int two)
   {
      int temp = a[one];
      a[one]=a[two];
      a[two]=temp; 
   }
   public static int quickMedian(int[] a)
   {
      int left=0;
      int right=a.length-1;
      int pivotIndex;  
      while(true)
      {
         if(left==right)
            return a[left];
            
         pivotIndex = (int)((Math.random()*(right-left)) +left); // random value between left and right
         pivotIndex = partition(a,left,right,pivotIndex);
         
         if(pivotIndex==(a.length/2))
            return a[pivotIndex]; //if pivotIndex is middle of array, return value
         
         else if(pivotIndex>(a.length/2))
            right= pivotIndex++;
         
         else 
            left = pivotIndex--;   
      
      }
   
   }
}