public abstract class StaffMember
{
   private String firstName;
   private String lastName;
   private int ID;
   private double payRate;
 
   public StaffMember(int ID, String firstName, String lastName, double payRate)
   {
      this.firstName = firstName;
      this.lastName = lastName;
      this.ID = ID;
      this.payRate = payRate;
   
   }
   //abstract methods that will be defined in child classes
   abstract double getPaid();
   //employeeType returns what kind of staffmember
   abstract String employeeType();
   
   public void setPayRate(double payRate)
   {
      this.payRate = payRate;
   }  
   //getters
   public String getFirstName()
   {
      return firstName;
   }
   public String getLastName()
   {
      return lastName;
   }
   public int getID()
   {
      return ID;
   }
   public double getPayRate()
   {
      return payRate;
   }



}