import java.util.Scanner;
/**
*This class represents a player for a game of pig.
* @author: David Oswari
* @version: 1.0
**/
public class Player
{
   private Dice dice;
   private String name;
   private int bank;
   private int points;
   
   /**
   * constructor for player
   * @param name
   *name of the player
   **/
   public Player(String name)
   {
      this.name= name;
   }
   /**
   *this method represents a players turn.
   *a turn ends when the player rolls a one, or chooses not to roll again.
   **/
   public void turn()
   {
      boolean turn = true;
      dice = new Dice();
      Scanner sc = new Scanner(System.in);
      beginTurn();
      while(turn==true)
      {
         dice.roll();
         if(dice.hasOne()==true)
         {
            if(dice.getValue1() == dice.getValue2())
               loseAllPoints();
            else
               loseTurnPoints();
               
            turn=false;
         }
         else
         {
            points+= dice.getSum();
            printTurn();
            System.out.print("ROLL AGAIN?\t");
            turn = askTurn();
         }
      }
      bank+=points;
      points=0;
      System.out.println("END TURN:\t Bank: " + getBank()+ "\n");
   }
  /**
  @return bank
  *returns the player's bank
  **/
   public int getBank()
   {
      return bank;
   }
 /**
 *@return points
 *returns the player's points
 **/
   public int getPoints()
   {
      return points;
   }
   /**
   *@return name
   returns the player's name
   **/
   public String getName()
   {
      return name;
   }
   /**
   *this message prints the roll, current points, and bank.
   **/
   public void printTurn()
   {
      System.out.print("Roll: "+ dice.printSum() + "\t Points: " + getPoints() + "\t Bank: " + getBank() + "\t");  
   }
   /**
   *this method is used at the beginning of the turn.
   *it prints the players name and bank.
   **/
   public void beginTurn()
   {
      System.out.println(getName() + "'s turn.\t Bank: " + getBank());
   }
   /**
   *this method sets points and bank to zero, and adds an additional message.
   **/
   public void loseAllPoints()
   {
      bank=0;
      points=0;
      printTurn();
      System.out.println("LOST ALL POINTS!");
   
   }
   /**
   *this method sets points to zero, and adds a message.
   **/
   public void loseTurnPoints()
   {
      points=0;
      printTurn();
      System.out.println("LOST TURN POINTS!");
   }
   /**
   *this method asks the player if they want to roll again.
   *@return response
   *checks if the response is either "y" or "n" and returns true or false accordingly.
   **/
   public boolean askTurn()
   {
      Scanner sc = new Scanner(System.in);
      String response = sc.next();
      boolean invalid = true;
      while(invalid)
      {
         if(response.equals("n") || response.equals("y"))
            invalid = false;
         
         else
         {
            System.out.print("Invalid response. Roll again?\t ");
            response=sc.next();
         }
      }
      
      if(response.equals("n"))
         return false;
      
      return true;
   }
}