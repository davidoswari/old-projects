public class Volunteer extends StaffMember
{
   public Volunteer(int ID, String firstName, String lastName, double payRate)
   {
      super(ID,firstName,lastName,payRate);
   }
   public double getPaid()
   {
      return 0; //volunteers don't get paid
   }
   public String employeeType()
   {
      return "Volunteer";
   }

}