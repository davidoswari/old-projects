/**
 * @author: David Oswari
 * @version: 2.0
 * 
 * payRate represents per hour pay rate
 * this class allows negative numbers for ID and payRate
 * 
 * added getOvertimeHours() method
 **/ 
public class Hourly extends StaffMember
{
 
   private double hours;
   private double overtimeHours;
    /**
   * @param ID
   * ID of Hourly
   * 
   * @param firstName
   * first name of Hourly
   * 
   * @param lastName
   * last name of Hourly
   * 
   * @param payRate
   * per hour pay rate of Hourly
   **/
   public Hourly(int ID, String firstName, String lastName, double payRate)
   {
      super(ID,firstName,lastName,payRate);
   }
   /**
    *@return payment
    * 
    * checks if hours are 80 and will return 0 if not
    * payment is hourly pay * hours + hourly pay * overtime hours
    * after payment is set, hours and overttime hours will be reset to 0
    * 
    **/
   public double getPaid()
   {

      if(hours==80)
      {
         double payment = (hours + overtimeHours)*this.getPayRate();
         hours=0;
         overtimeHours=0;
         return payment;
      }
      else
         return 0;
   }
   /**
    *@return hours 
    **/  
   public double getHours()
   {
      return hours;
   }

     /**
    *@return over time hours 
    **/
   public double getOvertimeHours()
   {
   return overtimeHours;  
   }
   
     /**
    *@param hours
    * hours that employee will work
    * when hours reaches 80, count overtime hours
    **/
   public void addHours(double hours)
   {
      while(hours>0)
      {
         if(this.hours==80)
         {
            overtimeHours++;
            hours--;
         }
         else
         {
            this.hours++;
            hours--;
         }
      }
   }
     /**
    *@return "Hourly" 
    **/
   public String employeeType()
   {
      return "Hourly";
   }

}