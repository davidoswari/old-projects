import java.util.*;
public class Assignment
{
/*
NOTES
m = 20 fields
file has 21 fields to account for rank
each field is integer between 1 and Ni (Ni is in range 2 to 10)
records [] is array of 10000 records
*/

   static File file = new File();
   static int[] N = File.N;
   final static int m =20;
   
   //variables used for mergesort
   static Record [] array = file.records;
   static int length;
   static Record [] MergeArray;
   
   //loop counters
   static int loopcounter1=0; //for gray order
   static int loopcounter2=0; //for horner's
   static int loopcounter3=0; //for radix
   
   /* 
   returns whether X precedes Y
   d is the least integer such that x.fields[d+1] != y.fields[d+1]
   totald is sum from x.fields[0] - x.fields[d]
   */

   public static boolean grayorder(Record x, Record y)
   {
      int d=-1;
      long totald=0;
      //while x and y fields match, add to totald
      while(x.fields[d+1]==y.fields[d+1])
      {
         totald+=x.fields[d+1];
         loopcounter1++;
         d++;
      }
      //even totald
      if(totald%2==0)
         return (x.fields[d+1] < y.fields[d+1]);
      //odd totald
      else
         return (y.fields[d+1] < x.fields[d+1]);
   }
   
   public static void computeHornersRank(Record x)
   {
      long i = x.fields[0];
      
      for(int j=1;j<m;j++)
      {
         loopcounter2++;
         long i2=0;   
         
         //if i even
         if(i%2==0)
            i2 = x.fields[j];
         //if i odd
         else
            i2 = N[j] - 1 - x.fields[j];
            
         i= i*N[j]+i2;
      }
      //set (m+1)st field to i, which is rank
      x.fields[m]=i;
   }
   
   public static Record[] radixsort()
   {
      //list L from set of records
      ArrayList<Record> L = new ArrayList<Record>(Arrays.asList(file.records));
      for(int j=m-1;j>=0;j--)
      {
         loopcounter3++;
      //form empty lists from L1 - LN
      //make arraylist holding other arraylists
         ArrayList<ArrayList<Record>> Lists = new ArrayList<ArrayList<Record>>(N[j]);
         for(int i=0;i<N[j];i++){
            loopcounter3++;
            Lists.add(new ArrayList<Record>());
         }
         
      //remove record from L and add to appropriate sublist
         while(L.size()>0)
         {
            loopcounter3++;
         //if even, append
            Record x = L.remove(0);
            if(x.fields[j]%2==0)
               Lists.get((int)(x.fields[j])).add(x);
            
            //if odd, prepend
            else
               Lists.get((int)(x.fields[j])).add(0,x);
         }
         //append all lists
         for(int i=0;i<Lists.size();i++)
         {
            loopcounter3++;
            L.addAll(Lists.get(i));
         }
      }
      Record[] temp = new Record[L.size()];   
      temp = L.toArray(temp);
      return temp;
   }
   
   /*
   sum of positive differences of corresponding fields, and for whole file is sum of these numbers
   method returns whole sum
   */
   public static int fullscore(Record[] records)
   {
      int fullscore=0;
      for(int i=0;i<records.length-1;i++)
      {
      //compare record to record after
         Record x = records[i];
         Record y = records[i+1];
         for(int j=0;j<m;j++)
         {
         //differences in record fields added to fullscore
            int diff = (int)Math.abs(x.fields[j] - y.fields[j]);
            fullscore+= diff;
         }
      }
      return fullscore;
   }
   
   /*
   finding the number of fields that are different between two records
   */
   public static int binaryscore(Record [] records)
   {
      int binaryscore=0;
      for(int i=0;i<records.length-1;i++)
      {
      //compare record to record after
         Record x = records[i];
         Record y = records[i+1];
         for(int j=0;j<m;j++)
         {
         //if fields are not equal, binary score + 1
            if(x.fields[j] != y.fields[j])
               binaryscore+=1;
         }
      }
      return binaryscore;
   }
   /*
   method used to test a file
   prints binary, full score, and loop counts for each method of sorting
   */
   public static void testOneFile(){
      
      System.out.println("original binary score: " + binaryscore(file.records));
      System.out.println("original full score: " + fullscore(file.records)+"\n");
                     
       //gray order testing  
      sort(array,1);
      System.out.println("grayorder binaryscore: " +binaryscore(array));
      System.out.println("grayorder fullscore: " +fullscore(array));
      System.out.println("grayorder loops = " +loopcounter1+"\n");
      
      //Horner's rank testing 
      
      array = file.records;
      //loop to compute rank for all records
      for(int i=0;i<file.records.length;i++)
         computeHornersRank(file.getRecord(i));
         
      sort(array,0);
      System.out.println("horners binary score: " + binaryscore(array));
      System.out.println("horners full score: "+ fullscore(array));
      System.out.println("horners loops = " + loopcounter2 + "\n");
         
      //radix sort testing
      Record temp[] = radixsort();
      System.out.println("radixsort binaryscore: "+binaryscore(temp));
      System.out.println("radixsort fullscore: " +fullscore(temp));
      System.out.println("radixsort loops = " +loopcounter3+"\n");
   }
   
   public static void main(String[] args)
   {
      testOneFile();
   }
   
   //********************************************MergeSort Algorithm****************************************************
   public static void sort(Record inputArr[], int n) {
      array = file.records;
      length = inputArr.length;
      MergeArray = new Record[length];
      doMergeSort(0, length - 1,n);
   }
 
   private static void doMergeSort(int lowerIndex, int higherIndex, int n) {
         
      if (lowerIndex < higherIndex) {
         int middle = lowerIndex + (higherIndex - lowerIndex) / 2;
            // Below step sorts the left side of the array
         doMergeSort(lowerIndex, middle, n);
            // Below step sorts the right side of the array
         doMergeSort(middle + 1, higherIndex, n);
            // Now merge both sides
         mergeParts(lowerIndex, middle, higherIndex, n);
      }
   }
 
   private static void mergeParts(int lowerIndex, int middle, int higherIndex, int n) {
   
      for (int i = lowerIndex; i <= higherIndex; i++) {
         MergeArray[i] = array[i];
         if(n==1)
            loopcounter1++;
         
         if(n==0)
            loopcounter2++;
      }
      int i = lowerIndex;
      int j = middle + 1;
      int k = lowerIndex;
      while (i <= middle && j <= higherIndex) {
      
      //n==0 is horner's
         if (n==0 && MergeArray[i].fields[20] <= MergeArray[j].fields[20]) {
            array[k] = MergeArray[i];
            i++;
            loopcounter2++;
         } 
         //n==1 is grayorder
         else if(n==1 && grayorder(MergeArray[i], MergeArray[j])) {
            array[k] = MergeArray[i];
            i++;
            loopcounter1++;
         }
         
         else {
            array[k] = MergeArray[j];
            j++;
            if(n==1)
               loopcounter1++;
            if(n==0)
               loopcounter2++;
         }
         k++;
      }
      while (i <= middle) {
         if(n==0)
            loopcounter2++;
         
         if(n==1)
            loopcounter1++;
         array[k] = MergeArray[i];
         k++;
         i++;
      }
   
   }
 
   

}