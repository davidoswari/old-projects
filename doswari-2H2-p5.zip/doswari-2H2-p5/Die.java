import java.util.Random;
/**
* This class represents a single die.
* @author: David Oswari
* @version: 1.0
**/
public class Die
{
   private int value;
   
   public Die()
   {
      value =1;
   }
   /**
   This method rolls the die, setting value as a random number between 1 and 6
   **/
   public void roll()
   {
      Random r= new Random();
      value =  r.nextInt(6) + 1;
   }
   /**
   @return value
   returns the value of the die rolled
   **/
   public int getValue()
   {
      return value;
   }
}