import java.util.ArrayList;

/**
*@author: David Oswari
*@version: 1.0
  *A tower containing disks in the Towers of Hanoi puzzle.
  */
public class Tower
{
   private ArrayList<Integer> disks;

   /**
     *Constructs a tower holding a given number of disks of decreasing size.
     *@param ndisks the number of disks
     */
   public Tower(int ndisks)
   {
      this.disks= new ArrayList<Integer>();
      for(int i=ndisks;i>0;i--)
         disks.add(i);
   }

   /**
     *Removes the top disk from this tower.
     *@return the size of the removed disk
     */
   public int remove()
   {     
      return disks.remove(disks.size()-1);
      
   }

   /**
     *Adds a disk to this tower.
     *@param size the size of the disk to add
     */
   public void add(int size)
   {
      disks.add(size);
   
   }
   public Integer get()
   {
      return(disks.get(0));
   }
   
   /**
    * Returns a string representation of the array list.
    * @return string representation of disks.
    */ 
   public String toString() 
   { 
      return disks.toString(); 
   }   
}

