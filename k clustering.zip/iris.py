import random
import math
from scipy.spatial import distance
import numpy as np
#get the test data
test_file = open("iris_data.txt", "r")
#sepal_length, sepal_width, petal_length, petal_width
f1 = test_file.readlines()
test_file.close()

#create 2d float array
rows = len(f1) 
cols = 5 #extra col to store cluster number
arr = [0]*rows
for i in range(rows):
    arr[i] = [0] * cols

for i in range(0,len(f1)):
    line_split = f1[i].split()
    arr[i][0] = float(line_split[0])
    arr[i][1] = float(line_split[1])
    arr[i][2] = float(line_split[2])
    arr[i][3] = float(line_split[3])
    arr[i][4] = 0
    

print("array created properly, now picking random centroids");
c1 = arr[random.randint(0,len(arr)-1)]
c2 = arr[random.randint(0,len(arr)-1)]
c3 = arr[random.randint(0,len(arr)-1)]

cluster1 = []
cluster2 = []
cluster3 = []

print("centroids chosen, assigning to clusters, 50 iterations")

iterations = 50
for i in range(0,iterations):
    for x in arr:
        #compute cosine distance to each centroid
        d1 = distance.cosine(np.array(x),np.array(c1))
        d2 = distance.cosine(np.array(x),np.array(c2))
        d3 = distance.cosine(np.array(x),np.array(c3))
        #assign to clusters
        if d1<d2 and d1<d3:
            cluster1.append(x)
            x[4] = 1
        elif d2<d1 and d2<d3:
            cluster2.append(x)
            x[4] = 2
        elif d3<d2 and d3<d1:
            cluster3.append(x)
            x[4] = 3
           
    #compute new centroid    
    temp = [0.0, 0.0, 0.0, 0.0, 0.0]
    for x in cluster1:
        for y in range(len(x)-1):
            temp[y]+=x[y]
    for y in range(4):
        temp[y] = temp[y]/len(cluster1)
    c1 = temp
    temp = [0.0, 0.0, 0.0, 0.0, 0.0]
    
    
    for x in cluster2:
        for y in range(len(x)-1):
            temp[y]+=x[y]
    for y in range(4):
        temp[y] = temp[y]/len(cluster2)
    c2 = temp

    temp = [0.0, 0.0, 0.0, 0.0, 0.0]
    for x in cluster3:
        for y in range(len(x)-1):
            temp[y]+=x[y]
    for y in range(4):
        temp[y] = temp[y]/len(cluster3)
    c3 = temp
    
print("end of iterations")

output = open("output.txt", "w+")
for i in arr:
    output.write(str(i[4]))
    output.write("\n")
output.close()



        
     
    



  
  
    
