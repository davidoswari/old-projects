
public class ShiftQueue{

   public static int [] makeQueue(int capacity)
   {
      if(capacity<0)
         return null;
      else
      {
         int [] queue = new int[capacity];
         for(int i=0;i<queue.length;i++)
         {
            queue[i]=-1; //assigns -1 in every spot
         }
         return queue;
      }
   }

   public static boolean addToEndOfQueue(int [] queue, int newItem)
   {
      if(queue==null|| newItem==-1)// checks if queue is null or newItem is -1
         return false;
   
      boolean result = false;
      for(int i=0;i<queue.length;i++)
      {
         if(queue[i]==-1)
         {
            queue[i]=newItem;
            result=true;
            return result;
            
         }
      }
      return result;
   }

   public static boolean removeFromFrontOfQueue(int [] queue)
   {
      if(queue==null)
         return false;
      boolean result = false;
      if(queue.length>0 && queue[0]!=-1) // checks if queue is empty or length=0
      {
         for(int i=0;i<queue.length-1;i++)
         {
            queue[i] = queue[i+1]; // assigns the number in next spot, in current spot
            result=true; 
         }
         queue[queue.length-1] = -1;
        
      }
   
      return result;
   }
   public static String queueString(int [] queue)
   {
      if(queue==null)
         return "";
      String str ="";
      for(int i=0;i<queue.length;i++)
      {
         if(queue[i]!=-1)// prints only if number is not -1
            str = str + " " + queue[i];
      }
      return str;
   }
}