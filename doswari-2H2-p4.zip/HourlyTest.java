import static org.junit.Assert.*;
import org.junit.Test;
import org.junit.*;

/**
 * @author: David Oswari
 * @version: 1.0
 * 
 * this code tests all methods in Hourly class
 **/ 

public class HourlyTest
{
private Hourly steve,bill;
/**
 * sets up two Hourlys
 **/
@Before
public void setUp()
{
steve = new Hourly(2,"Steve","Jobs",60000);
bill = new Hourly(-2,"Bill" , "Gates", -50000);
}
/**
 * checks firstName
 **/
@Test
public void getFirstNameTest()
{
  assertTrue(bill.getFirstName().equals("Bill"));
  assertTrue(steve.getFirstName().equals("Steve"));
}
/**
 * checks lastName
 **/
@Test
public void getLastNameTest()
{
  assertTrue(bill.getLastName().equals("Gates"));
  assertTrue(steve.getLastName().equals("Jobs"));
}
/**
 * checks ID
 **/
@Test
public void getIDTest()
{
  assertTrue(bill.getID()==-2);
  assertTrue(steve.getID()==2);
}
/**
 * checks getPayRate and setPayRate methods
 **/
@Test
public void getSetPayRate()
{
assertTrue(steve.getPayRate()==60000);
assertTrue(bill.getPayRate()==-50000);
steve.setPayRate(20202);
bill.setPayRate(-1);
assertTrue(steve.getPayRate()==20202);
assertTrue(bill.getPayRate()==-1);
}
/**
 * tests getPaid method without any hours worked
 **/
@Test
public void getPaidTest()
{  
assertTrue(steve.getPaid()==0);
assertTrue(bill.getPaid()==0);
}
/**
 * tests getHours and addHours
 **/
@Test
public void addHoursTest()
{
  steve.addHours(70);
 assertTrue(steve.getHours()==70);
 assertTrue(steve.getOvertimeHours()==0);
 
 bill.addHours(100);
 assertTrue(bill.getHours()==80);
 assertTrue(bill.getOvertimeHours()==20); 
}
/**
 * tests getPaid with hours
 * checks if hours are reset after
 **/
@Test
public void getPaidTest2()
{
  steve.addHours(79);
  assertTrue(steve.getPaid()==0);
  steve.addHours(1);
  assertTrue(steve.getPaid()==steve.getPayRate()*80);
  assertTrue(steve.getHours()==0);
  assertTrue(steve.getOvertimeHours()==0);
  
  bill.addHours(90);
  assertTrue(bill.getHours()==80);
  assertTrue(bill.getOvertimeHours()==10);
  assertTrue(bill.getPaid()==-4500000);
  assertTrue(bill.getHours()==0);
  assertTrue(bill.getOvertimeHours()==0);
}

/**
 * checks that employeeType is correct
 **/
@Test
public void employeeTypeTest()
{
assertTrue(steve.employeeType().equals("Hourly"));
assertTrue(bill.employeeType().equals("Hourly"));
}
}