//David Oswari
//Value class
public class Value
{
   String sval;
   double dval;
   int tag;
   
   //default constructor
   public Value()
   {
      sval = "";
      tag=2;
   }
   //constructor with string parameter
   public Value(String value)
   {
      //if value is a String
      if(value.charAt(0)== '"')
      {
         sval = value.substring(1);
         tag = 0;
      }
      //if value is a double
      else
      {
         dval = Double.parseDouble(value);
         tag = 1;
      }
   }
   
   //method used to change value
   public void setValue(String value)
   {
   //if value is a String
      if(value.charAt(0)== '"')
      {
         sval = value.substring(1);
         tag = 0;
      }
      //if value is a double
      else
      {
         dval = Double.parseDouble(value);
         tag = 1;
      }
   }
   
   //to String method
   public String toString()
   {
   //if it stores a double
      if(tag ==1)
         return dval+"";
           
      return sval;
   }
   
   //method adds two values and returns a value
   public Value addValue(Value v)
   {
   //check if both doubles
      if(tag==1 && v.tag==1)
         return new Value("" + (dval + v.dval));
   
   //else returns value with invalid tag
      return new Value();
   }
   
   //method subtracts values and returns a value
   public Value subtractValue(Value v)
   {
   //check if both doubles
      if(tag==1 && v.tag==1)
         return new Value("" + (dval-v.dval));
      
   //returns value with invalid tag
      return new Value();
   
   }
   
   //method multiplies values and returns a value
   public Value multiplyValue(Value v)
   {
   //check if both doubles
      if(tag==1 && v.tag==1)
         return new Value("" + (dval*v.dval));
   
   //else returns value with invalid tag
      return new Value();
   
   }
   
   //method divides two values and returns a value
   public Value divideValue(Value v)
   {
   //check if both doubles
      if(tag==1 && v.tag==1)
         return new Value("" + (dval/v.dval));
         
   //else returns value with invalid tag
      return new Value();
   
   }

}