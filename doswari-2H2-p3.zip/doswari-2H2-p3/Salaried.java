public class Salaried extends StaffMember
{
 //payRate represents annual salary
   
   public Salaried(int ID, String firstName, String lastName, double payRate)
   {
      super(ID,firstName,lastName,payRate);
   }
   public double getPaid()
   {
      return this.getPayRate()/12;//monthly pay
   }
   public String employeeType()
   {
      return "Salaried";
   }

}