//David Oswari G01013002
//Document class is a doubly linked list with a dummy node
//each node is a Line
public class Document
{
   private Line head = new Line("dummy");
   private int numberOfLines=0;

   private class Line
   {
      Line next;
      Line prev;
      String text;
      int characters;
   
      public Line(String text)
      {
         this.text = text;
         characters = text.length(); 
      }
   }
   //prints out the entire list with line numbers
   public void printList()
   {
      int count =1;
      Line p = head.next;
      while(p!=null)
      {
         System.out.println(count + ": " + p.text);
         p = p.next;
         count++;
      }
   }
   //print out a specific line, but does not print line number
   public void printLine(int target)
   {
      if(target>0 && target<=numberOfLines)
      {    
         Line p = findLine(target); 
         System.out.println(p.text);
      }  
   }
   public String getText(int target)
   {
      String text = "";
      if(target>0)
      {
         Line p = findLine(target);
         text = p.text;
      }
      return text;
   }
   public boolean isEmpty()
   {
      return head.next==null;
   }
   //adds to end
   public void addLine(String text)
   {
      Line newL = new Line(text);
   //if Document is empty
      if(head.next==null)
      {
         head.next= newL;
         newL.prev = head;
         numberOfLines++;
      }
      else
      {
         Line p = head.next;
         while(p.next!=null)//traverse the document
            p = p.next;
         
         p.next = newL;
         newL.prev = p;
         numberOfLines++;
      }   
   }
   //inserts Line after target line
   public void insertLine(String text, int target)
   {
      Line newL = new Line(text);
      Line p = head;
      
      for(int i = 0;i<target;i++)
         p = p.next;
      
      newL.next = p.next;             
      p.next = newL;
      p.next.prev = newL;
      newL.prev = p;
      numberOfLines++;
      
   }
   //this method deletes the target line
   public void deleteLine(int target)
   {
      if(target>0 && target<=numberOfLines)
      {
         Line p = findLine(target);
            
         p.prev.next = p.next;//skips p
         if(p.next!=null)//in case p is the only line in the document
            p.next.prev = p.prev;
         numberOfLines--;
      
      }
   }
   //method returns the target line
   public Line findLine(int target)
   {
      Line p = head;
      for(int i=0;i<target;i++)
         p = p.next;
         
      return p;
   }
   
   public int getNumberOfLines()
   {
      return numberOfLines;
   }
   
   //used to change text at a line
   public void setText(String newText ,int target)
   {
      Line p = findLine(target);
      p.text = newText;
      p.characters = newText.length();
   }
   
   //return the number of characters stored in the target Line
   public int length(int target)
   {
      Line p = findLine(target);
      return p.characters;
   }
}