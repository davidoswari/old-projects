import java.util.Scanner;
import java.io.File;
public class StaffDemo
{
   private static Scanner sc;
  
   public static void main(String [] args)
   {
     /**
      * @author: David Oswari
      * @Version 2.0
      * 
      * New Changes
      * added a payAll(staff) in main method to be used in a test
      * 
      * main method is used to test the methods
      * testing the methods
      * make all Hourly in staff work hours
      **/
     StaffMember[] staff = createStaff();
     
     payAll(staff);
     
      for(StaffMember x: staff)
      {
         if(x instanceof Hourly)
         {
            Hourly y= (Hourly)x;
            y.addHours(80);
         }
      }
      payAll(staff);
   }
   public static StaffMember[] createStaff()
   {
      StaffMember[] staff = null;
   
      try
      {
         sc = new Scanner(new File("Staff.txt"));
         staff = new StaffMember[sc.nextInt()];
         /**nextInt() would be number of employees in staff**/
      
         int count=0;
         while(sc.hasNext())
         
         { 
            String employeeType = sc.next();
            /**check what employeeType to create appropriate StaffMember**/
            if(employeeType.equals("Salaried"))
            {
               staff[count]= new Salaried(sc.nextInt(),sc.next(),sc.next(),sc.nextDouble());
               count++;
            }
            if(employeeType.equals("Executive"))
            {
               staff[count]= new Executive(sc.nextInt(),sc.next(),sc.next(),sc.nextDouble());
               count++;
            }
            if(employeeType.equals("Volunteer"))
            {
               staff[count]= new Volunteer(sc.nextInt(),sc.next(),sc.next(),sc.nextDouble());
               count++;
            }
            if(employeeType.equals("Hourly"))
            {
               staff[count]= new Hourly(sc.nextInt(),sc.next(),sc.next(),sc.nextDouble());
               count++;
            }
         }
         
      
      }
      catch(Exception e)
      {
      }
      return staff;
   }
   /**
    *@param staff
    * the array of StaffMembers
    * 
    * payAll method prints firstname, lastname, employeeType and getPaid methods
    * Hourly will return 0 if they have not at worked at least 80 hours
    **/
   public static void payAll(StaffMember[] staff)
   {
      for(StaffMember x: staff)
      {
         System.out.println(x.getFirstName() + " " + x.getLastName() + " (" + x.employeeType() + ") : $" + formatNumber(x.getPaid()));
      }
   }
   /**
    * @param num
    * number that will be formatted to two decimal places
    * 
    * @return formatted number
    **/ 
   
   public static String formatNumber(double num)
   {
      return String.format( "%.2f", num );
     
   }

}