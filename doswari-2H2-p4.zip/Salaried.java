/**
 * @author: David Oswari
 * @version: 1.0
 * 
 * no new changes
 * 
 * this class allows negative numbers for ID and payRate
 * payRate represents annual salary
 * getPaid() method returns monthly pay
 **/ 
public class Salaried extends StaffMember
{
    /**
   * @param ID
   * ID of Salaried
   * 
   * @param firstName
   * first name of Salaried
   * 
   * @param lastName
   * last name of of Salaried
   * 
   * @param payRate
   * annual salary of Salaried
   **/  
   public Salaried(int ID, String firstName, String lastName, double payRate)
   {
      super(ID,firstName,lastName,payRate);
   }
   /**
    * @return monthly salary
    **/ 
   public double getPaid()
   {
      return this.getPayRate()/12;
      
   }
   
   /**
    * @return "Salaried"
    **/ 
   public String employeeType()
   {
      return "Salaried";
   }

}