public class ProperQueue
{
   private int size = 0;
   private Integer[] elements;

   public ProperQueue(int maxCapacity)
   {
      if(maxCapacity<0)//if less than 0, sets as 0
         maxCapacity=0;
   
      Integer[] elements = new Integer[maxCapacity];
      for(int i=0;i<elements.length;i++)//sets everything as null
         elements[i]=null;
         
      this.elements = elements;
   }
   
   public int getSize()
   {
      return size;
   }
   
   public int getCapacity()
   {
      return elements.length;
   }
   
   public boolean isFull()
   {
      if(size==elements.length)
         return true;
   
      return false;
   }
   
   public boolean isEmpty()
   {
      if(size == 0)
         return true;
         
      return false;
   }
   
   public String toString()
   {
      String result = "";
      for(int i=0;i<elements.length;i++)
      {
         if(elements[i]!=null)
         {
            if(i==0)
            {
               result = elements[0]+ "";
            }
            else
               result = result + " " + elements[i];
         
         }
      
      }
      return result;
   }
   
   public boolean add(Integer num)
   {
   //Runtime exceptions
      if(num==null)
         throw new RuntimeException("Cannot add null");
      else if(isFull())
         throw new RuntimeException("Queue full");
         
      for(int i=0;i<elements.length;i++)
      {
         if(elements[i]==null)
         {
            elements[i]= num;
            size++;
            break;
            //stops after num is put in elements
         }
      }
      return true;
   
   
   }
   
   public boolean offer(Integer num)
   {
   //same as add, except returns null
      if(isFull())
         return false;
   
      if(num==null)
         throw new RuntimeException("Cannot add null");
         
      else
      {
         for(int i=0;i<elements.length;i++)
         {
            if(elements[i]==null)
            {
               elements[i]= num;
               size++;
               break;
            }
         }
         return true;
      }
   }
   
   public Integer remove()
   {
      if(isEmpty())
         throw new RuntimeException("Queue empty");
         
      int removed = elements[0];
      for(int i=0;i<elements.length-1;i++)
         elements[i]=elements[i+1];
      elements[elements.length-1]= null;
   
      size--;
      return removed;
   }
   
   public Integer poll()
   {
   //same as remove except returns null
      if(isEmpty())
         return null;
         
      int removed = elements[0];
      for(int i=0;i<elements.length-1;i++)
         elements[i]=elements[i+1];
      elements[elements.length-1]= null;
      size--;
      return removed;
   
   }
   
   public Integer element()
   {
      if(isEmpty())
         throw new RuntimeException("Queue empty");
     
      return elements[0];
   }
   public Integer peek()
   {
      if(isEmpty())
         return null;
   
      return elements[0];
   }

   
   
   
   
}