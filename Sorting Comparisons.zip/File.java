public class File
{
   int m =20;
   static int [] N;
   static int size = 100000;
   Record [] records;
   
   public File()
   {
   //create N array
      N = new int[m];
      for(int i=0;i<m;i++)
      {
      //fill with random number between 2 and 10
         N[i] = (int)(Math.random()*9 + 2);
      }
      
   //create record array
      records = new Record[size];
      for(int i=0;i<size;i++)
      {
         records[i] = new Record(N);
      }  
   }
   
   /*
   method returns size
   */
   public int size()
   {
      return size;
   }
   
   /*
   method gets record at position x
   */
   public Record getRecord(int x)
   {
      return records[x];
   }
   
   /*
   printing method for testing purposes
   */
   public void printFile()
   {
      for(int i=0;i<size;i++)
         System.out.println(records[i]);
   }

}