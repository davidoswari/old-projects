import java.lang.*;
public class Record
{
   //20 fields m
   //21st field holds rank
   //each field has int value 0 to (Ni-1)
   //all records have same structure
   long [] fields= new long[21];
   int m =20;
   
   public Record(int[] N)
   {
   //create field array of size m
      for(int i=0;i<m;i++)
      {
      //field values range from 0 - (N[i]-1)
         fields[i] = (long)(Math.random()*N[i]);
      }
   }
   
   /*
   toString for testing purposes
   */
   public String toString()
   {
      String temp = "";
      for(int i=0;i<m;i++)
      {
         temp = temp + this.fields[i] + ", ";
      }
      temp += "rank = " + this.fields[m];
      return temp;
   }
}