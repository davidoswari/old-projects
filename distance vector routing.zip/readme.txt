The program will print the output, which i just wrote in output.txt
it will look for the file network.txt to read input from.