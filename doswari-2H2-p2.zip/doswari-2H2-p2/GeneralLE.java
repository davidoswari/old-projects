public class GeneralLE
{
   private double a;
   private double b;
   private double c;
   private double x;
   private double y;
   public GeneralLE(double a, double b, double c, double x)
   {
      this.a =a;
      this.b =b;
      this.c=c;
      this.x=x;
      this.y=(c-a*x)/b;
   }
   public double value()
   {
      return c;
   }
   public double getX()
   {
      return x;
   }
   public double getY()
   {
      return y;
   }
   public void setX(double x)
   {
      this.x =x;
      this.y = (c-(a*x))/b;
   }
   public void setY(double y)
   {
      this.y=y;
      this.x= (c-(b*y))/a;
   }
   public String toString()
   {
      return formatNumber(a) + " * x + " + formatNumber(b) + " * y = " + formatNumber(c); 
   }
   //same method in SlopeIntercept
   public String formatNumber(double num)
   {
      return String.format( "%.2f", num ); // formats num to two decimal places
     
   }
   
   public SlopeInterceptLE toSlopeInterceptLE()
   {
      double newB = (this.c/this.b);
      double newM = -1* this.a/this.b;
      SlopeInterceptLE result = new SlopeInterceptLE(newM,newB,this.x);
      
      return result;
   
   }
   


}