import java.io.*;
import java.util.Scanner;
import java.lang.StringBuffer;

//David Oswari G01013002
//This program is a line editor
public class LineEditor
{
//global variables
   public static Scanner sc = new Scanner(System.in);
   public static Document d= new Document();
   public static Document lineBuffer;
   public static StringBuffer stringBuffer = new StringBuffer("");
   public static String loadedFile;
  
   public static void main(String [] args) throws FileNotFoundException
   {
      menu();
      boolean running = true;
      while(running)
      {
         System.out.print("\n-> ");
         String input = sc.nextLine();
         System.out.println("");
         switch(input)//cases correspond to the menu options
         {
            //print menu
            case "m":
               {
                  menu();
                  break;
               }
            //load file
            case "l":
               {
                  loadFile();
                  break;
               }
            //create new lines     
            case "nl":
               {
                  newLine();
                  break;
               } 
            //show all lines
            case "sa":
               {
                  showAll();
                  break;
               }
            //show a range of lines
            case "sr":
               {
                  showRange();
                  break;
               }
            //show a line
            case "sl":
               {
                  showLine();
                  break;
               }
            //edit a line
            case "el":
               {
                  editLine();
                  break;
               }
            //paste lines
            case "pl":
               {
                  pasteLines();
                  break;
               }
            //delete a line
            case "dl":
               {
                  deleteLine();
                  break;
               }
            //copy a range of lines
            case "cr":
               {
                  copyRange();
                  break;
               }
            //delete a range of lines
            case "dr":
               {
                  deleteRange();
                  break;
               }
            //write to file
            case "w":
               {
                  writeToFile();
                  break;
               }
             //write to file and quit  
            case "wq":
               {
                  writeToFile();
                  running = false;
                  break;
               }
            //quit     
            case "q":
               {
                  running = false;
                  break;
               }
               //if user input is not valid
            default:
               {
                  System.out.println("command not found");
               }  
            
         }
      }
   }
   
   //this method will create and write to a file
   public static void writeToFile() throws FileNotFoundException
   {
      String fileName;
     //if file was previously loaded, write to that file. else prompt user 
      if(loadedFile==null)
      {
         System.out.print("write to file: ");
         fileName = sc.nextLine();
      }
      else
         fileName = loadedFile;
     
      //make sure the file name is not the name of this file or Document. This is to prevent overwriting
      if(fileName.equals("Document.java")|| fileName.equals("LineEditor.java"))
         System.out.println("Can't create this file");
         
      else
      {
         PrintStream console = System.out;
         
      //change printstream to new file
         File file = new File(fileName);
         FileOutputStream fos = new FileOutputStream(file);
         PrintStream ps = new PrintStream(fos);
         System.setOut(ps);
        
      //used a for loop instead of printList so it would not print line numbers
         for(int i=0;i<=d.getNumberOfLines();i++)
            d.printLine(i);
         
      //change printstream back to console
         System.setOut(console);
      }
   }
   
   /*this method loads a file
   this will not change current document if the file is not found*/
   public static void loadFile()
   {
      System.out.println("load: ");
      String fileName = sc.nextLine();
      File file = new File(fileName);
      
      try
      {
      //makes a new document
         Document temp = new Document();
         Scanner fileScanner = new Scanner(file);
      
      //read file and add lines to document
         while(fileScanner.hasNextLine())
         {
            String text = fileScanner.nextLine();
            temp.addLine(text);
         }   
         d= temp;
         loadedFile=fileName;
      }
      
      //if file does not exist
      catch(FileNotFoundException e)
      {
         System.out.println("file not found");
      }
      
   }
   
   //this method prints and displays the menu
   public static void menu()
   {
      System.out.println("Menu: m         Delete line: dl");
      System.out.println("Load file: l    Delete range: dr");
      System.out.println("Show all: sa    Copy range: cr");
      System.out.println("Show line: sl   Paste line: pl");
      System.out.println("Show range: sr  Write to file:  w");
      System.out.println("New Line: nl    Quit: q");
      System.out.println("Edit line: el   Write and quit: wq");
   }
   
   //prints the menu in editLine() method
   public static void lineMenu()
   {
      System.out.println("\tShow line:  s");
      System.out.println("\tCopy to string buffer:  c");
      System.out.println("\tCut:  t");
      System.out.println("\tPaste from string buffer:  p");
      System.out.println("\tEnter new substring:  e");
      System.out.println("\tDelete substring:  d");
      System.out.println("\tQuit line:  q");
   }
   
   //this method is used to create new lines
   public static void newLine()
   {
      //will continually ask if user wants to add lines
      while(true)
      {
         System.out.print("type line? (y/n): ");
         
         String response = yesOrNo();//this will force user to give "y" or "n"            
         if(response.equals("y"))
         {
         //if document is empty, make line one
            if(d.isEmpty())
            {
               System.out.print("1: ");
               String text = sc.nextLine();
               d.addLine(text);
            }
            
            /*if not line one, ask user after which line to add a new line
            if user inputs 0, it will add to front of document*/
            else
            {
               System.out.print("insert after line: ");
               int ln = getValue();
               
               //check user input
               if(ln>d.getNumberOfLines() || ln<0)
                  System.out.println("line number is out of range");
               else
               {
                  System.out.print((ln+1) + ": ");
                  String temp = sc.nextLine();
                  d.insertLine(temp,ln);
               }
            }
         }
         else
            break;
      }
   }
   //this method will print the entire document
   public static void showAll()
   {
      d.printList();
   }
   //this will print a range of documents (inclusive)
   public static void showRange()
   {
   //user input
      System.out.print("show from line: ");
      int from = getValue();
      System.out.print("to line: ");
      int to = getValue();
      //check inputs  
      if(from<=0 || from > d.getNumberOfLines() || to<from || to > d.getNumberOfLines())
         System.out.println("invalid range");
      else
      {
      //printing the range   
         for(int i=from;i<=to;i++)
            d.printLine(i);
      }
   }
   //this method prints a desired line
   public static void showLine()
   {
      System.out.print("show line: ");
      int ln = getValue();
      //check user input
      if(ln>d.getNumberOfLines() || ln<=0)
         System.out.println("line number is out of range");
      else
         d.printLine(ln);
   
   }
  
  //this method is for editing a line
   public static void editLine()
   {
   //user input
      System.out.print("line number: ");
      int ln = getValue();
      //check user input
      if(ln>d.getNumberOfLines() || ln<=0)
         System.out.println("line number is out of range");
      else
      {
      //print statements
         show(ln);
         boolean running = true;
         while(running)
         {
            lineMenu();
            System.out.print("\n->");
            String input = sc.nextLine();
            System.out.println("");
         //switch case corresponds to line menu options
            switch(input)
            {
               case "s"://show line and scale
                  {
                     show(ln);
                     break;
                  }
               case "c"://copy substring
                  {
                     copySubstring(ln);
                     break;
                  }
               case "t"://cut substring
                  {  cutSubstring(ln);
                     break;
                  }
               case "p"://paste (insert before)
                  {
                     pasteSubstring(ln);
                     break;
                  }
               case "e"://insert new substring
                  {
                     insertSubstring(ln);
                     break;
                  }
               case "d"://delete substring
                  {
                     deleteSubstring(ln);
                     break;
                  }
               case "q"://quit editting
                  {
                     running = false;
                     break;
                  }
               default://in case input is not a valid command
                  {
                     System.out.println("command not found");
                  }
            }
         }
      }
   }
    //this method prints the scale used in the show() method
   public static void scale(int length)
   {
      String numbers = "";
      String scale = "";
      
      for(int i=0;i<length;i++)
      {
        //0,10,20...
         if(i%10==0)
         {
            scale+="|";
            numbers+=i;
         }
         //5,15,25...
         else if(i%5==0)
         {
            scale+="+";
            numbers+=i;
         }
         //other numbers
         else
         {
            scale+="-";
            if(i<10 || (i-1)%5!=0)//necessary to align numbers with scale
               numbers+=" ";
         }
      }
      System.out.println(numbers);
      System.out.println(scale);
   }

   //this method shows the line and prints the scale used in the editLine method
   public static void show(int ln)
   {
      scale(d.length(ln));
      d.printLine(ln);
   }
   
   //this method draws the line ^^^^^
   //used when deleting substrings
   public static void range(int from, int to, int length)
   {
      String range = "";
      for(int i=0; i<length;i++)
      {
         if(i>=from && i<=to)
            range+="^";
         else
            range+=" ";
      
      }
      System.out.println(range);
   }
   
   //this method will delete a target line
   public static void deleteLine()
   {
      System.out.print("delete which line?: ");
      int ln = getValue();
      //check input
      if(ln>d.getNumberOfLines() || ln<=0)
         System.out.println("line number is out of range");
      else
         d.deleteLine(ln);
   }
   //this method will copy a range of lines(inclusive) and put them in the line buffer
   public static void copyRange()
   {
   //initialize the line buffer
      lineBuffer = new Document();
   //user input
      System.out.print("copy from line: ");
      int from = getValue();
      System.out.print("to line: ");
      int to = getValue();
      //check inputs
      if(from<=0 || from > d.getNumberOfLines() || to<from || to > d.getNumberOfLines())
         System.out.println("invalid range");
      else
      {
      //put lines into buffer
         for(int i= from; i<=to;i++)
            lineBuffer.addLine(d.getText(i));
      }
   }
   //this method will paste the lines in lineBuffer into the document
   public static void pasteLines()
   {
      System.out.print("insert after line: ");
      int pos = getValue();
      //check input
      if(pos<0 || pos > d.getNumberOfLines())
         System.out.println("line number is out of range");
      else
      {
         for(int i= 1; i<=lineBuffer.getNumberOfLines();i++)
            d.insertLine(lineBuffer.getText(i),pos++);
      }
   }
   
   //this method will delete a range of lines
   public static void deleteRange()
   {
   //user input
      System.out.print("delete from line: ");
      int from = getValue();
      System.out.print("delete to line: ");
      int to = getValue();
      //check inputs
      if(from<=0 || from > d.getNumberOfLines() || to<from || to > d.getNumberOfLines())
         System.out.println("invalid range");
      else
      {
         for(int i= to; i>=from; i--)
            d.deleteLine(i);     
      }
   }
   //this method copies a substring into the stringBuffer
   public static void copySubstring(int ln)
   {
      show(ln);
      //user inputs
      System.out.print("from position: ");
      int from = getValue();
      System.out.print("to position: ");
      int to = getValue();
      //check inputs
      if(from<0 || from >=d.length(ln) || to<from || to >=d.length(ln))
         System.out.println("invalid range");
      else
      {
      //put in buffer
         String substring = d.getText(ln).substring(from, to+1); 
         stringBuffer = new StringBuffer(substring);
         System.out.println("copied:");
         show(ln);
         range(from, to, d.length(ln));
      }
   }
   //this method cuts a substring into the stringBuffer
   public static void cutSubstring(int ln)
   {
      show(ln);
      //user inputs
      System.out.print("from position: ");
      int from = getValue();
      System.out.print("to position: ");
      int to = getValue();
      //check inputs
      if(from<0 || from >= d.length(ln) || to<from || to >= d.length(ln))
         System.out.println("invalid range");
      else
      {
      //put in buffer
         String substring = d.getText(ln).substring(from, to+1);
         stringBuffer = new StringBuffer(substring);
         System.out.println("cut:");
         show(ln);
         range(from, to, d.length(ln));
      //changing text in line
         String front = d.getText(ln).substring(0,from);
         String back = d.getText(ln).substring(to+1);
         d.setText(front+back,ln);
      }
   }
   //this method copies the lines in lineBuffer to document
   public static void pasteSubstring(int ln)
   {
      show(ln);
      //user input   
      System.out.println("insert at position: ");
      int pos = getValue();
      //check input
      if(pos<0 || pos>d.length(ln))
         System.out.println("invalid range");
      else
      {
      //changing text in line
         String front = d.getText(ln).substring(0,pos);
         String back = d.getText(ln).substring(pos);
         d.setText(front+ stringBuffer.toString() +back,ln);
         show(ln);
      }
   }
   //this method gets a substring from user and inserts it
   public static void insertSubstring(int ln)
   {
      show(ln);
      //user input
      System.out.println("insert at position: ");
      int pos = getValue();
      //check input
      if(pos<0 || pos>d.length(ln))
         System.out.println("invalid range");
      else
      {
         System.out.println("text: ");
         String substring = sc.nextLine();
      //change text in line
         String front = d.getText(ln).substring(0,pos);
         String back = d.getText(ln).substring(pos);
         d.setText(front+ substring +back,ln);
         show(ln);
      }
   }
   public static void deleteSubstring(int ln)
   {
      show(ln);
      //user inputs
      System.out.print("from position: ");
      int from = getValue();
      System.out.print("to position: ");
      int to = getValue();
      //check inputs
      if(from<0 || from >= d.length(ln) || to<from || to >= d.length(ln))
         System.out.println("invalid range");
      
      else
      {
         show(ln);
         range(from, to, d.length(ln));
         System.out.print("y/n: ");
         String input = yesOrNo();
      
      //changing text in line
         if(input.equals("y"))
         {  
            String front = d.getText(ln).substring(0,from);
            String back = d.getText(ln).substring(to+1);
            d.setText(front+back,ln);
            show(ln);
         }
      }
   }
   //this method is used to get a yes or no input from user
   public static String yesOrNo()
   {
      String response = sc.nextLine();
         //check user input to see if it is "y" or "n"
         //if not will loop until response is "y" or "n"
      while(!response.equals("y") && !response.equals("n"))
      {
         System.out.print("invalid input.(y/n): ");
         response = sc.nextLine();
      }
      return response;
   }
   
   //get int from user, and makes sure value can be accepted.
   public static int getValue()
   {
      int value = sc.nextInt();
      String clear = sc.nextLine();//enter character is stored in scanner after sc.nextInt()
      return value;
   }
   
}