/**
* This program is the driver for a Pig game.
* @author: David Oswari
* @version: 1.0
**/
import java.io.IOException;
import java.util.Scanner;
public class Pig
{
   private static Player one, two;
   
   public static void main(String[] args)
   {
      makePlayers(); 
      playGame();
      printWinner();
   }
   /**
   *This method initializes two players
   **/
   public static void makePlayers()
   {
      Scanner sc = new Scanner(System.in);
      System.out.print("First player's name?  ");
      String name1 = sc.next();
      System.out.print("Second players name?  ");
      String name2 = sc.next();
      one = new Player(name1);
      two = new Player(name2);
   
   }
   /**
   *this method is what controls the game.
   *the loop breaks when one player has a bank of 100 or more
   **/
   public static void playGame()
   {
   
      Scanner sc = new Scanner(System.in);
      
      while(true)
      {   
         one.turn();
         if(one.getBank()>=100)
            break;
            
         two.turn();
         if(two.getBank()>=100)
            break;
      }
   }
   /**
   *This method prints a message for the winner of the game.
   **/
   public static void printWinner()
   {
      if(one.getBank()>=100)
         System.out.println(one.getName() + " is the Winner!");
      else
         System.out.println(two.getName() + " is the Winner!");
   }   
}