/**
   * @author: David Oswari
   * @version: 1.0
   * 
   * this class allows negative numbers for ID and payRate
   **/
public abstract class StaffMember
{
   private String firstName;
   private String lastName;
   private int ID;
   private double payRate;
 
   /**
   * @param ID
   * ID of StaffMember
   * 
   * @param firstName
   * first name of StaffMember
   * 
   * @param lastName
   * last name of StaffMember
   * 
   * @param payRate
   * pay rate of StaffMember
   **/
   public StaffMember(int ID, String firstName, String lastName, double payRate)
   {
      this.firstName = firstName;
      this.lastName = lastName;
      this.ID = ID;
      this.payRate = payRate;
   }
   
   /**
    * abstract method that will be defined in child classes
    *@return payment
    **/
   abstract double getPaid();
   /**
    * abstract method that will be defined in child classes
    * @return employee type
    **/ 
   abstract String employeeType();
   /** 
    * @param payRate
    * pay rate of StaffMember
    **/
   public void setPayRate(double payRate)
   {
      this.payRate = payRate;
   }
   /**
    *@return first name 
    **/
   public String getFirstName()
   {
      return firstName;
   }
   
     /**
    *@return last name
    **/
   public String getLastName()
   {
      return lastName;
   }
   
    /**
    *@return ID
    **/
   public int getID()
   {
      return ID;
   }
   
    /**
    *@return pay rate
    **/
   public double getPayRate()
   {
      return payRate;
   }



}